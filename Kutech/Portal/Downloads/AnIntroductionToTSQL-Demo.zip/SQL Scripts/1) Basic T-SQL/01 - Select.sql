/*------------------------------------------------------------------------------------
	SELECT
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Using the * Symbol
-----------------------------------------------

/*
	* represents 'ALL'
	It returns every column in the table
	Note the colours used in SSMS
*/

select *
from JupyterDatabase.dbo.basicSELECT


-----------------------------------------------
-- Writing a Column List
-----------------------------------------------

/*
	We shall return just a couple of columns from the above table
	This is the more precise and Best Practice approach
	Requires prior knowledge of the columns
*/

select firstName, lastName
from JupyterDatabase.dbo.basicSELECT


-----------------------------------------------
-- Square Brackets [ and ]
-----------------------------------------------

/*
	Sometimes column names are 'unfriendly'
*/

select *
from JupyterDatabase.dbo.myWideTable


/*
	Let's pull some specific columns
*/

select firstName, lastName, infoColumn4, infoColumn12
from JupyterDatabase.dbo.myWideTable


/*
	We can do the same but with square brackets
*/

select [firstName], [lastName], [infoColumn4], [infoColumn12]
from JupyterDatabase.dbo.myWideTable


/*
	Let's try the following
*/

select firstName, lastName, table
from JupyterDatabase.dbo.myWideTable


/*
	Now let's try the same with square brackets
*/

select firstName, lastName, [table]
from JupyterDatabase.dbo.myWideTable


/*
	There are other column name issues as well
	We cannot start a column with a special character
*/

select firstName, lastName, .5Percent
from JupyterDatabase.dbo.myWideTable


/*
	Likewise a name with spaces
*/

select firstName, lastName, space here
from JupyterDatabase.dbo.myWideTable


/*
	These can all be resolved with square brackets
*/

select firstName, lastName, [.5Percent], [space here]
from JupyterDatabase.dbo.myWideTable


/*
	NOTE - SSMS allows 'SELECT TOP X Rows'
*/

