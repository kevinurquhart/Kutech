/*------------------------------------------------------------------------------------
	FROM
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Basic FROM Query
-----------------------------------------------

/*
	Declaratively we SELECT columns FROM a table
*/

select *
from JupyterDatabase.dbo.basicSELECT


-----------------------------------------------
-- 3-Part Name
-----------------------------------------------

/*
	This is the format we have seen so far
		<databaseName>.<schema>.<tableName>
	It is the complete path
*/

select *
from JupyterDatabase.dbo.basicSELECT


-----------------------------------------------
-- 2-Part Name
-----------------------------------------------

/*
	This requires us to be 'in' the right database
*/

select *
from dbo.basicSELECT


/*
	Why the error?

	We are in the 'master' database

	We need to change this in SSMS or via USE
		Don't rely on the dropdown
		Passing code around may cause issues
*/

use JupyterDatabase

select *
from dbo.basicSELECT


-----------------------------------------------
-- 1-Part Name
-----------------------------------------------

/*
	Risky operation as you may not be in the right schema

	SQL looks in 'your' schema first
*/

select *
from basicSELECT


/*
	I am in the dbo schema, therefore all good

	Let's try an experiment...

	First we'll look with a user called JupyterDatabase
*/

use JupyterDatabase;

execute as user = 'JupyterDemo';

select *
from basicSELECT

revert;


/*
	But what happens if we pass our query to another user?

	This user defaults to the HR schema, not DBO
*/

use JupyterDatabase;

execute as user = 'JupyterDemoHR';

select *
from basicSELECT

revert;


/*
	This is because we have 2 tables
*/

select * from dbo.basicSELECT
select * from hr.basicSELECT


/*
	Hence we always recommend 2-part naming as the minimum
	3-part is thorough but potentially excessive
	2-part is a happy medium
*/
