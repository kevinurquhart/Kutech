/*------------------------------------------------------------------------------------
	WHERE
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Equality
-----------------------------------------------

/*
	This is the test table that we will use throughout this demo
*/

select *
from JupyterDatabase.hr.employee


/*
	We wish to SELECT columns FROM our table WHERE employeeID equals 1
*/

select *
from JupyterDatabase.hr.employee
where employeeID = 1


/*
	String values require single quotes

	We shall look for anyone with my surname
*/

select *
from JupyterDatabase.hr.employee
where lastName = 'Urquhart'


/*
	The standard date format in SQL is YYYY-MM-DD

	This also requires the single quote

	We shall search on the Date of Birth column (dob)
*/

select *
from JupyterDatabase.hr.employee
where dob = '1979-02-27'


/*
	Other date formats are implicitly converted by SQL Server

	Use whichever feels most comfortable
*/

select *
from JupyterDatabase.hr.employee
where dob = '27 Feb 1979'

select *
from JupyterDatabase.hr.employee
where dob = '19790227'

select *
from JupyterDatabase.hr.employee
where dob = '1979/02/27'


-----------------------------------------------
-- Inequality
-----------------------------------------------

/*
	Note the SQL language states <>

	T-SQL also allows the use of !=

	Let's look for anyone without the title 'Mr'
*/

select *
from JupyterDatabase.hr.employee
where title <> 'Mr'

select *
from JupyterDatabase.hr.employee
where title != 'Mr'


/*
	Greater than works in the same way

	Obtain all employees other than 1, 2, 3
*/

select *
from JupyterDatabase.hr.employee
where employeeID > 3


/*
	We can also add the equals sign to create less than or equal to

	Obtain only employeeIDs 1, 2, 3
*/

select *
from JupyterDatabase.hr.employee
where employeeID <= 3


/*
	We can also use these with dates

	Date of Birth greater than 1st Jan 2000
*/

select *
from JupyterDatabase.hr.employee
where dob > '2000-01-01'


/*
	It does work with strings, but there are caveats
*/

select *
from JupyterDatabase.hr.employee
where lastName > 'U'

-- It is very literal with the interpretation


-----------------------------------------------
-- LIKE
-----------------------------------------------

/*
	Find anyone with a surname starting with U R Q

	It can be anything it likes beyond those 3 letters

	We use % as a wildcard in SQL
*/

select *
from JupyterDatabase.hr.employee
where lastName like 'Urq%'


/*
	The wildcard doesn't need to be at the start

	Anyone with a first name that ends with V I N
*/

select *
from JupyterDatabase.hr.employee
where firstName like '%vin'


/*
	We don't have to look for either trailing of preceding characters

	We can double end the wildcard

	Search for anyone with E V anywhere in the first name, but in that order
*/

select *
from JupyterDatabase.hr.employee
where firstName like '%ev%'


/*
	We can also place wildcards throughout

	Let's search for anyone with a U and H in their lastname

	Must be U first, then H but anywhere within the string and with any characters between them
*/

select *
from JupyterDatabase.hr.employee
where lastName like '%u%h%'


-----------------------------------------------
-- IN
-----------------------------------------------

/*
	If we know our values (we're not using wildcards) we can provide a list

	Therefore anyone with firstNames IN the list 'Kevin' and 'Diana'
*/

select *
from JupyterDatabase.hr.employee
where firstName in ('Kevin', 'Diana')


/*
	This also works just as well with numbers instead of strings
*/

select employeeID, firstName, lastName
from JupyterDatabase.hr.employee
where employeeID in (5, 11, 39)


-----------------------------------------------
-- BETWEEN
-----------------------------------------------

/*
	This is designed to deal with ranges of data

	We could write IN statements for most of these, but the lists could be too large to be sensible

	Therefore we use BETWEEN to define ranges

	Hence employeeIDs BETWEEN 1 and 10
*/

select *
from JupyterDatabase.hr.employee
where employeeID between 1 and 10

-- Note BETWEEN is inclusive as per the above


/*
	People misunderstand the inclusiveness of BETWEEN

	Let's look at employeeID 121
*/

select *
from JupyterDatabase.hr.employee
where employeeID = 121


/*
	This record was created in Jan 2019

	Let's look for all records created in Jan 2019 using BETWEEN
*/

select *
from JupyterDatabase.hr.employee
where createdDate between '2019-01-01' and '2019-01-31'


/*
	So BETWEEN is NOT inclusive???

	Or is our query incorrect?
*/

select *
from JupyterDatabase.hr.employee
where createdDate between '2019-01-01' and '2019-01-31 23:59:59.997'

-- SQL Server is very picky with dates


/*
	It can be easier to re-write a BETWEEN as two statements
*/

select *
from JupyterDatabase.hr.employee
where createdDate >= '2019-01-01'
and createdDate < '2019-02-01'


-----------------------------------------------
-- NOT
-----------------------------------------------

/*
	This is simply a negative keyword which we combine with the operators above

	NOT LIKE
	NOT IN
	NOT BETWEEN
*/

select *
from JupyterDatabase.hr.employee
where firstName not like 'Ke%'

select *
from JupyterDatabase.hr.employee
where employeeID not in (1, 2, 3, 4, 5, 6, 7, 8)

select *
from FoodNStuff.hr.employee
where createdDate not between '2018-01-01' and '2018-12-31 23:59:59.999'


-----------------------------------------------
-- COMBINING OPERATORS using AND and OR
-----------------------------------------------

-----------------------------------------------
-- AND
-----------------------------------------------

/*
	Let's get our employees where their IDs are less than or equal to 10
*/

select *
from JupyterDatabase.hr.employee
where employeeID <= 10


/*
	Now we'll look for employees with date of birth less than 1980
*/

select *
from JupyterDatabase.hr.employee
where dob < '1980-01-01'


/*
	We need employeeIDs less than or equal to 10 AND dob less than 1980

	As implied, we can use AND
*/

select *
from JupyterDatabase.hr.employee
where employeeID <= 10
and dob < '1980-01-01'


/*
	We can combine as many times as we like:

	EmployeeID IN the IDs 1 to 10
	firstName which starts with K (LIKE K)
	Date of Birth prior to 1980 (less than 1980)
	CreatedDate in 2018 (between 2018-01-01 and 2018-12-31 23:59:59.999)
*/

select *
from JupyterDatabase.hr.employee
where employeeID in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
and firstName like 'K%'
and dob < '1980-01-01'
and createdDate between '2018-01-01' and '2018-12-31 23:59:59.999'


-----------------------------------------------
-- OR
-----------------------------------------------

/*
	We wish to suggest "one or the other"

	We might need firstName like K OR firstName like D
*/

select *
from JupyterDatabase.hr.employee
where firstName like 'K%'
or firstName like 'D%'


/*
	This has a potentially slippery slope we need to avoid

	Let's find all employees where:

	firstName like 'K' OR firstName like 'D'
	AND managerID less than 10
*/

select *
from JupyterDatabase.hr.employee
where firstName like 'K%'
or firstName like 'D%'
and managerID < 10


/*
	The above results show a glaring issue

	We have numerous records where the managerID is larger than 10

	This is the same as the age old maths problem:

	2 + 2 - 2 + 2 * 2 - 2 / 2 = ?

	We need to use brackets
*/

select *
from JupyterDatabase.hr.employee
where (firstName like 'K%'
or firstName like 'D%')
and managerID < 10


-----------------------------------------------
-- Pattern Matching
-----------------------------------------------

/*
	We can now pick out specific values, but what if we need to do a more generic pattern match?

	We need a subset of data for this, specifically we will focus on the NI Number in our table for employeeIDs 1, 2, 3, 4, 5
*/

select employeeID, firstName, lastName, NINumber
from JupyterDatabase.hr.employee
where employeeID <= 5


/*
	We need to look for any NI Number starting with an alphabetical character

	We can use [ and ] to define the range of a single character

	In this case we want the first single character to be A to Z inclusive
*/

select employeeID, firstName, lastName, NINumber
from JupyterDatabase.hr.employee
where employeeID <= 5
and NINumber like '[a-z]%'


/*
	The same logic applies when looking for a character that must be a number

	We look for a first character in the range 0 to 9
*/

select employeeID, firstName, lastName, NINumber
from JupyterDatabase.hr.employee
where employeeID <= 5
and NINumber like '[0-9]%'


/*
	This is a rare occasion where NOT isn't used

	To negate a single character range we use ^ (shift + 6)

	Let's find a first character that is not an alphabetical character
*/

select employeeID, firstName, lastName, NINumber
from JupyterDatabase.hr.employee
where employeeID <= 5
and NINumber like '[^a-z]%'


/*
	This is a single character, therefore we can say we wish this to be anywhere in the string

	We can start with a wildcard, end with a wildcard, and look for a character in between

	We can also specify a specific set of values for our range, such as ! , -
*/

select employeeID, firstName, lastName, NINumber
from JupyterDatabase.hr.employee
where employeeID <= 5
and NINumber like '%[!,-]%'


/*
	Finally, what if we want specifically the second character to be something?

	We can use the underscore _ in order to specify a single wildcard character

	Let's imagine we wish to find anyone who's NI Number has the second character of either ! or -
*/

select employeeID, firstName, lastName, NINumber
from JupyterDatabase.hr.employee
where employeeID <= 5
and NINumber like '_[!-]%'


