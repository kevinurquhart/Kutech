/*------------------------------------------------------------------------------------
	TOP
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Basic Usage
-----------------------------------------------

/*
	We just want to see 10 records from our Employee table
*/

select top 10 *
from JupyterDatabase.hr.employee


-----------------------------------------------
-- Brackets
-----------------------------------------------

/*
	This will yield the same results as the above, but is better practice to use
*/

select top (10) *
from JupyterDatabase.hr.employee


-----------------------------------------------
-- Percentage
-----------------------------------------------

/*
	Let's have a quick look at how many rows are in the table
*/

select *
from JupyterDatabase.hr.employee


/*
	We can see that there are 224 records

	This works nicely for our purposes:

	224 / 4 = 56

	Let's look for the TOP 25% of data in our table
*/

select top (25) percent *
from JupyterDatabase.hr.employee

