/*------------------------------------------------------------------------------------
	ORDER BY
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Basic Ordering
-----------------------------------------------

/*
	We can return data, but what about presentation?

	Should we use Excel or PowerBI or another application or can we cater for this in SQL?

	We can use ORDER BY for this exact purpose
*/

select *
from JupyterDatabase.hr.employee
order by firstName


/*
	SQL Server otherwise has no obligation to order your data when it return it to you

	You can ONLY guarantee order if you tell it explicitly

	We can order bi-directionally using ASC or DESC
*/

select *
from JupyterDatabase.hr.employee
order by firstName asc

select *
from JupyterDatabase.hr.employee
order by firstName desc


/*
	We can order by multiple columns as required

	We have some specific records in mind...
*/

select *
from JupyterDatabase.hr.employee
where firstName in ('Fredericka', 'Ivan', 'Todd')


/*
	We wish to order these by both firstName and dob

	We can do this by providing an ordering list
*/

select *
from JupyterDatabase.hr.employee
where firstName in ('Fredericka', 'Ivan', 'Todd')
order by firstName, dob


/*
	We also don't need to adhere to the same ordering direction throughout

	We can vary within the list
*/

select *
from JupyterDatabase.hr.employee
where firstName in ('Fredericka', 'Ivan', 'Todd')
order by firstName asc, dob desc


-----------------------------------------------
-- Ordering with TOP
-----------------------------------------------

/*
	The most common usage is to combine TOP with ORDER BY

	Without this we are just returning X records

	Most likely we want the "X oldest records" or "X most recent dates"

	Let's look at the 5 oldest employees
*/

select top (5) *
from JupyterDatabase.hr.employee
order by dob


/*
	Or maybe we'll look at the 3 youngest

	This simply involves reversing the order
*/

select top (3) *
from JupyterDatabase.hr.employee
order by dob desc

