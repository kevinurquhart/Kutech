/*------------------------------------------------------------------------------------
	DISTINCT
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Basic Distinct
-----------------------------------------------

/*
	As with TOP, this is a subset of SELECT and therefore used exclusively after SELECT

	It affects all columns present in the SELECT line

	Let's have a look at some data
*/

select employeeID, firstName, lastName
from JupyterDatabase.hr.employee
where lastName in ('Fowler', 'Howard')


/*
	This shows we have a lot of duplication throughout the results as shown

	Let's DISTINCT the above

	We should see no change as it works on ALL columns and we are including employeeID

	We still get 6 results showing
*/

select distinct employeeID, firstName, lastName
from JupyterDatabase.hr.employee
where lastName in ('Fowler', 'Howard')


/*
	If we remove the employeeID we should start to filter our results accordingly

	We should get 5 results instead of the original 6
*/

select distinct firstName, lastName
from JupyterDatabase.hr.employee
where lastName in ('Fowler', 'Howard')


/*
	Despite the 6 records we only have 2 last names present (as per our filter)

	Therefore let's distinct only the lastName
*/

select distinct lastName
from JupyterDatabase.hr.employee
where lastName in ('Fowler', 'Howard')

