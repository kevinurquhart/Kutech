/*------------------------------------------------------------------------------------
	NULL
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- IS NULL
-----------------------------------------------

/*
	Let's look at a record in our table
*/

select *
from JupyterDatabase.hr.employee
where employeeID = 1


/*
	We can see that the managerID is null

	(Note it "is null" not that it equals null)

	Therefore if we try conventional methods it will fail
*/

select *
from JupyterDatabase.hr.employee
where managerID = null


/*
	Hence we have the IS NULL syntax available to us
*/

select *
from JupyterDatabase.hr.employee
where managerID is null


/*
	As we are used to in the WHERE clause, we negate with NOT
*/

select *
from JupyterDatabase.hr.employee
where managerID is not null


-----------------------------------------------
-- ISNULL
-----------------------------------------------

/*
	Just to confuse everyone we have ISNULL with no spaces

	This is a method of dealing with NULL values rather than filtering them
*/

select employeeID, managerID
from JupyterDatabase.hr.employee
where employeeID <= 5


/*
	What if we wish to replace the null with 0?

	We can use ISNULL(value, replacementIfValueIsNull)
*/

select employeeID, managerID,
		isnull(managerID, 0)
from JupyterDatabase.hr.employee
where employeeID <= 5

