/*------------------------------------------------------------------------------------
	Statements and Batches
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Statement
-----------------------------------------------

/*
	A statement is a single command or query

	The following is a statement:
*/

select *
from JupyterDatabase.hr.employee
where employeeID = 1


-----------------------------------------------
-- Batch
-----------------------------------------------

/*
	A batch is any text sent to the SQL Server

	It can be one or more statements

	The following is a batch:
*/

select *
from JupyterDatabase.hr.employee
where employeeID = 1

select *
from JupyterDatabase.hr.employee
where firstName = 'Kevin'


-----------------------------------------------
-- Semi-colon ;
-----------------------------------------------

/*
	In the SQL language every statement should be terminated by a semi-colon

	This is optional in T-SQL but recommended as best practice

	(Microsoft say they will make it compulsory in the future)
*/

select *
from JupyterDatabase.hr.employee
where employeeID = 1;


-----------------------------------------------
-- GO
-----------------------------------------------

/*
	This is a purely Microsoft implementation

	It is a method of breaking text into batches

	The following consists of 4 statements broken into 2 batches
		Batch 1 = 1 statement
		Batch 2 = 3 statements
*/

select *
from JupyterDatabase.hr.employee
where employeeID = 1;
go

select *
from JupyterDatabase.hr.employee
where firstName = 'Kevin';

select *
from JupyterDatabase.hr.employee
where lastName = 'Urquhart';

select *
from JupyterDatabase.hr.employee
where dob between '1980-01-01' and '1990-01-01';
go

