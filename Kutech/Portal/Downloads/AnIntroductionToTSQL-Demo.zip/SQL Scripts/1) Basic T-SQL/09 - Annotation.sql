/*------------------------------------------------------------------------------------
	Annotations
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Single Line Comments
-----------------------------------------------

/*
	This is done by starting a line with two dashes --

	This creates a single line comment

	The comment must follow the dashes and not be on a subsequent line

	They can appear anywhere throughout SQL code
*/

-- This statement looks only at OrderID 1
select *
from JupyterDatabase.sales.basicSales
-- orderID must equal 1
where orderID = 1


-----------------------------------------------
-- Multi Line Comments
-----------------------------------------------

/*
	This is a multi line comment

	It allows any number of comments between the / and * combinations
*/


/*
This statement looks at orderIDs 1, 3, and 5

Initial Creation: 2020-10-01

Change Log:  v1.1 - KU - 2020-10-02
*/

select *
from JupyterDatabase.sales.basicSales
-- v1.1 - Changed to be a list
where orderID in (1, 3, 5)
