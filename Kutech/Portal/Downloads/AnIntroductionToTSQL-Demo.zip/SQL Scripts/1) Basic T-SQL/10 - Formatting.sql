/*------------------------------------------------------------------------------------
	Formatting
------------------------------------------------------------------------------------*/

/*
	Formatting is a case of personal preference

	SQL Server doesn't care as long as keywords and column names are whole
*/

select				firstName			,		lastName
		, dob				,
					NINumber


FROM JupyterDatabase.hr.employee			;


/*
	Many people have many styles they like to use

	The most common is to capitalise keywords
*/

SELECT *
FROM JupyterDatabase.hr.employee
WHERE employeeID = 1;


/*
	This harks back to the days when SQL editors were black and white

	Nowadays we have colour editors and therefore capitalisation is mostly redundant

	However, this causes more arguments than you may believe

	Personally, I find it a personal preference

	Likewise tabbing
*/

select		firstName,
			lastName,
			dob
from		JupyterDatabase.hr.employee
where		employeeID = 1;


/*
	Overall, if you have a company standard, adhere to it

	If not, code how you feel most comfortable

	It can be hard to read and comprehend code written in an alien style

	It's all personal preference, SQL Server itself doesn't care.
*/
