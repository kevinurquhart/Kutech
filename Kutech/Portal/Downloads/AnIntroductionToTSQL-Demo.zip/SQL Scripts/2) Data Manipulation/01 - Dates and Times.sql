/*------------------------------------------------------------------------------------
	Dates and Times
------------------------------------------------------------------------------------*/

/*
	For these demos we will use another table
*/

select *
from JupyterDatabase.sales.basicSales;


-----------------------------------------------
-- Current Date and Time
-----------------------------------------------

/*
	We can do this in two ways
*/

select current_timestamp,		-- SQL language
		getDate();				-- T-SQL only


-----------------------------------------------
-- DatePart
-----------------------------------------------

/*
	This is a built in function which allows us to return 'portions' of a date and time

	Some of the 'portions' are as follows (this isn't exhaustive, we will see more soon):

		yy / yyyy / year		- Year of the date passed in
		MM / month				- Month of the date passed in
		dd / day				- Day of the date passed in
		dw						- Day of the week of the date passed in  (this is 1 to 7)
*/

select orderID, orderDate,
		datepart(yy, orderDate),
		datepart(MM, orderDate),
		datepart(dd, orderDate),
		datepart(dw, orderDate)
from JupyterDatabase.sales.basicSales
where orderID = 1;


/*
	This function can also be used in a WHERE clause

	On my install orderID was placed on day of week 6, which is Friday.

	Let's look for other orders placed on a Friday
*/

select *
from JupyterDatabase.sales.basicSales
where datepart(dw, orderDate) = 6;


-----------------------------------------------
-- DateAdd
-----------------------------------------------

/*
	This is a built in function which allows us to add portions of dates to a date

	Some more of the 'portions' are as follows:

		ww / week				- Week of the date passed in
		hh / hour				- Hour of the date passed in
		n / minute				- Minute of the date passed in (we use n as m is month)
		s / second				- Second of the date passed in
		ms / millisecond		- Millisecond of the date passed in
*/

select orderID, orderDate,
		dateadd(yy, 1, orderDate),		-- Add a year to the orderDate
		dateadd(n, 1, orderDate)		-- Adds a minute to the orderDate
from JupyterDatabase.sales.basicSales
where orderID = 1;


/*
	A common usage is for a dynamic between

	For example "orders in the last 7 days"

	Note the use of the negative value
*/

select *
from JupyterDatabase.sales.basicSales
where orderDate between dateadd(dd, -7, current_timestamp) and current_timestamp;


-----------------------------------------------
-- DateDiff
-----------------------------------------------

/*
	This is a built in function which shows the difference between two dates and times

	We can ascertain how many portions of time exist between two dates and times

	DATEDIFF(portionOfDateTime, startDateTime, endDateTime)
*/

select datediff(dd, '2020-01-01', '2020-01-03'),
		datediff(s, '2020-01-01', '2020-01-03');


-----------------------------------------------
-- General Conversions
-----------------------------------------------

/*
	There are also several general functions which exist that are simpler and blunter to use

	Feel free to use whichever you are most comfortable with
*/

select '2020-07-31 12:37:59.123',
		year('2020-07-31 12:37:59.123'),
		month('2020-07-31 12:37:59.123'),
		day('2020-07-31 12:37:59.123');


