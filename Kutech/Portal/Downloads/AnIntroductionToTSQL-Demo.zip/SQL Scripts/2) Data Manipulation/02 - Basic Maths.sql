/*------------------------------------------------------------------------------------
	Basic Maths
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Simple Maths
-----------------------------------------------

/*
	Normal computer symbols apply within SQL
*/

select 1 + 2,
        5 - 3,
        6 * 3,
        10 / 5;


/*
	We can also do maths on columns
*/

select orderID, salesAmount, taxAmount, (salesAmount + taxAmount)
from JupyterDatabase.sales.basicSales;


-----------------------------------------------
-- Divide by Zero
-----------------------------------------------

/*
	This does not work and will result in an error
*/

select 1 / 0;


-----------------------------------------------
-- NULL cannot be used
-----------------------------------------------

/*
	NULL is 'unknown' and therefore cannot be used in maths

	For example, adding something to something unknown is still an unknown
*/

select 55 + null,
		2 - null,
		null * 10,
		7 / null;


-----------------------------------------------
-- DataTypes can cause problems
-----------------------------------------------

/*
	Let's try a simple example and see what happens
*/

select 10 / 3;


/*
	SQL Server is a database and follows stringent rules

	We wouldn't want a database to change datatypes at will

	We explicitly tell a database we are using integers, it uses integers

	We need to tell it we're flexible by converting to a decimal
*/

select 10. / 3,
        10 / 3.,
		convert(decimal(10, 8), 10) / 3;


/*
	This will also work with columns

	(Redundant example, but the principle stands)
*/

select (salesAmount * 1.) + taxAmount
from JupyterDatabase.sales.basicSales
where orderID = 1;


-----------------------------------------------
-- Conversion Failures
-----------------------------------------------

/*
	SQL CAN see '5' as 5, but this isn't wise
*/

select 10 / '5';


/*
	Non-numerics lead to error
*/

select 1 / 'a';

-----------------------------------------------
-- Basic Datatypes
-----------------------------------------------

-- We used Convert above

select convert(decimal(4, 2), 10);


-- Note how precise datatypes are:

select convert(decimal(4, 2), 10.111);


