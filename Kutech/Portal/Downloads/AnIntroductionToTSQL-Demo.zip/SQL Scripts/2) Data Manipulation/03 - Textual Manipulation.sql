/*------------------------------------------------------------------------------------
	Textual Manipulation
------------------------------------------------------------------------------------*/

/*
	We can see issues with the data as presented

	We may want information such as the employee who made the sale
*/

select *
from JupyterDatabase.sales.basicSales;


-----------------------------------------------
-- REPLACE
-----------------------------------------------

/*
	REPLACE(string, whatToLookFor, whatToReplaceWith)

	In this demo we'll change the phrase 'This is txt' to 'This is text'
*/

-- Replacing just a single letter
select replace('This is txt', 'x', 'ex');

-- Replacing a whole word
select replace('This is txt', 'txt', 'text');


-----------------------------------------------
-- Length of Data
-----------------------------------------------

/*
	There are two functions we can use for this:
		LEN()		 - This returns the trimmed length (removes white space)
		DATALENGTH() - This returns the actual length (including white space)
*/

select len('This string has 3 spaces at the end   '),
        datalength('This string has 3 spaces at the end   ');


-----------------------------------------------
-- TRIM
-----------------------------------------------

/*
	This removes white space from around a string
		Left Trim will remove white spaces from the start of a string
		Right Trim will remove white spaces from the end of a string
		Trim will remove both start and end white spaces
*/

select ltrim('     Removes left spaces only     '),
		rtrim('     Removes right spaces only     '),
		trim('     Removes left and right spaces     '), -- SQL Server 2017 and above
		ltrim(rtrim('     Removes left and right spaces     ')); -- SQL Server 2016 and below


-----------------------------------------------
-- LEFT and RIGHT
-----------------------------------------------

/*
	This will take X characters from either the left or right of a string
*/

select left('two words', 3),
        right('two words', 5);


/*
	Note, unlike most programming languages the number of characters is not limited to the length of the string
*/

select left('This string', 1000);


/*
	To find the employee name we can utilise this method

	The phrase "Order taken by: " is 16 characters
	We can determine the length of the employee name is the length of the phrase (LEN) minus 16 (our repeating phrase)
*/

select right(infoCol, len(infoCol)-16)
from JupyterDatabase.sales.basicSales;


-----------------------------------------------
-- SUBSTRING
-----------------------------------------------

/*
	This allows us to extract a portion of a string using a custom start point and number of characters to then read

	SUBSTRING(string, startPosition, lengthFromStart)

	Imagine we have 'One, Two, Three' and wish to return 'Two' as our result

	We need to start at position 6 (ONE is 3, the comma is 4, the space is 5, we start at the 6th) and read 3 characters
*/

select substring('One, Two, Three', 6, 3);


/*
	We could therefore also use this as a method of extracting the employee name

	We start at position 17 and read to the end of the string
*/

select substring(infoCol, 17, len(infoCol))
from JupyterDatabase.sales.basicSales;


-----------------------------------------------
-- CHARINDEX
-----------------------------------------------

/*
	Standing for 'character index' this function finds the position (index) of a character within a given string

	CHARINDEX(characterToFind, string, startingPosition)

	We will find the comma in the string 'random,character'
*/

select charindex(',', 'random,character', 1);


/*
	We can also find the start of whole words
*/

select charindex('char', 'random,character', 1);


/*
	Maybe we want to find the second R within the string

	We can do this by skipping the first character and starting at the 2nd
*/

select charindex('r', 'random,character', 2);


/*
	Finally, we can use the function to tell us if a character exists at all
*/

select charindex('x', 'random,character', 1);


-----------------------------------------------
-- Combining SUBSTRING and CHARINDEX
-----------------------------------------------

/*
	It can sometimes be more powerful to combine operators than use them in isolation

	Substring and Charindex used together can make for very dynamic solutions to problems

	We already have a solution for "Order taken by: John Smith"
		BUT what if a decision is made to change the message to "Cashier Reference: "

	Our code breaks

	But what if we make it dynamic?

	We know that all messages have ": " in them.  Let's use that to our advantage
*/

select charindex(': ', 'Order taken by: John Smith', 1),
        charindex(': ', 'Cashier Reference: John Smith', 1);


/*
	Now that we have this working we can move on

	We now know that our employee name starts at the location of ": " plus 2 characters (to accommodate ": " itself)

	So we can consider a SUBSTRING of our string, starting 2 characters beyond ": " and running to the end of the string
*/

select substring('Order taken by: John Smith',
					charindex(': ', 'Order taken by: John Smith', 1) + 2,
						len('Order taken by: John Smith')),
		substring('Cashier Reference: John Smith',
					charindex(': ', 'Cashier Reference: John Smith', 1) + 2,
						len('Cashier Reference: John Smith'));


/*
	We can convert this to the column in our table
*/

select infoCol, substring(infoCol, charindex(': ', infoCol, 1) + 2, len(infoCol))
from JupyterDatabase.sales.basicSales;
