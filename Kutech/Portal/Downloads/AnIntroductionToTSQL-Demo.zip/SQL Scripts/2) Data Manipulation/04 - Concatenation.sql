/*------------------------------------------------------------------------------------
	Concatenation
------------------------------------------------------------------------------------*/

/*
	This varies wildly depending on your version of SQL Server

	We shall discuss all of them here, but pay most attention to that which will work for you
*/

-- Check your version
select @@version;


-----------------------------------------------
-- The Plus Symbol
-----------------------------------------------

/*
	This is the "works in all versions" solution but there is an obvious confusion that arises
*/

select 1 + 1;

select '1' + '1';


/*
	However, ignoring these, we can use it to concatenate string columns
*/

select customerTitle, customerFName, customerLName,
		customerTitle + customerFName + customerLName
from JupyterDatabase.sales.basicSales;


/*
	There are two issues
		There are no spaces between concatenated columns
		NULL isn't dealt with

	We'll deal with NULL first

	Any column which may be NULL needs to be run through the ISNULL function
*/

select customerTitle, customerFName, customerLName,
		customerTitle + isnull(customerFName, '') + customerLName
from JupyterDatabase.sales.basicSales;


/*
	Now we need to deal with the lack of spaces

	We can add them between each column
*/

select customerTitle, customerFName, customerLName,
		customerTitle + ' ' + isnull(customerFName, '') + ' ' + customerLName
from JupyterDatabase.sales.basicSales;


/*
	This is better but we now end up with a double space where we have the replaced NULL value

	We need to use some trickery
		If we concatenate anything with NULL we are left with NULL
		Therefore ISNULL(customerFirstName + ' ', '') will yield our required result
*/

select customerTitle, customerFName, customerLName,
		customerTitle + ' ' + isnull(customerFName + ' ', '') + customerLName
from JupyterDatabase.sales.basicSales;


/*
	This solves our problem.  Although it is messy.

	Imagine if we added this throughout
*/

select customerTitle, customerFName, customerLName,
		isnull(customerTitle + ' ', '') + isnull(customerFName + ' ', '') + isnull(customerLName, '')
from JupyterDatabase.sales.basicSales;


-----------------------------------------------
-- CONCAT
-----------------------------------------------

/*
	SQL Server 2012 added CONCAT

	This isn't perfect but it's a lot cleaner
*/

select customerTitle, customerFName, customerLName,
		concat(customerTitle, customerFName, customerLName)
from JupyterDatabase.sales.basicSales;


/*
	This deals with NULLs just fine, but we still have our lack of spaces

	We need to add those independently using + again
*/

select customerTitle, customerFName, customerLName,
		concat(customerTitle + ' ', customerFName + ' ', customerLName)
from JupyterDatabase.sales.basicSales;


-----------------------------------------------
-- CONCAT_WS
-----------------------------------------------

/*
	SQL Server 2017 added CONCAT_WS

	This solves all our problems in a very neat and tidy manner

	WS stands for 'with spacer' and you can specify which spacer you would like

	We will stick with an actual space as our spacer
*/

select customerTitle, customerFName, customerLName,
		concat_ws(' ', customerTitle, customerFName, customerLName)
from JupyterDatabase.sales.basicSales;


/*
	For completeness, let's see how this works with an exclamation as a spacer
*/

select customerTitle, customerFName, customerLName,
		concat_ws('!', customerTitle, customerFName, customerLName)
from JupyterDatabase.sales.basicSales;
