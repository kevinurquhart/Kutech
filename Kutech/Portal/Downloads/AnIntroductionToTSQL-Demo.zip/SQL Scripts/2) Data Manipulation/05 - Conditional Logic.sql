/*------------------------------------------------------------------------------------
	Conditional Logic
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- CASE Statement
-----------------------------------------------

/*
	Let's have a look at our basic table
*/

select *
from JupyterDatabase.sales.basicSales;


/*
	We wish to classify the sales we've made into target groups
		Over �500 is 'Amazing'
		�101 to �499 is 'Great'
		All others are 'Average'

	CASE WHEN someCriteria is comparable to anotherCriteria THEN doThis ELSE doThat END
*/

select salesAmount,
		case when salesAmount >= 500 then 'Amazing'
				when salesAmount between 101 and 499 then 'Great'
				else 'Average' end
from JupyterDatabase.sales.basicSales;


/*
	Note this is cascading logic therefore it exits as soon as a match is found

	Hence we could write this as follows:
*/

select salesAmount,
		case when salesAmount >= 500 then 'Amazing'
				when salesAmount >= 101 then 'Great'
				else 'Average' end
from JupyterDatabase.sales.basicSales;


/*
	We can also vary the logic within each WHEN clause

	We shall make Bob Jones always register as 'Amazing' yet leave all others alone
*/

select infoCol, salesAmount,
		case when infoCol like '%Bob Jones' then 'Amazing'
				when salesAmount >= 500 then 'Amazing'
				when salesAmount >= 101 then 'Great'
				else 'Average' end
from JupyterDatabase.sales.basicSales;


/*
	A very common use for this is to translate 'day part of week' or to change month numbers into months

	Below we can see the 'day of week' translation
*/

select orderDate,
		case datepart(dw, orderDate)
			when 1 then 'Sunday'
			when 2 then 'Monday'
			when 3 then 'Tuesday'
			when 4 then 'Wednesday'
			when 5 then 'Thursday'
			when 6 then 'Friday'
		else 'Saturday' end
from JupyterDatabase.sales.basicSales;
