/*------------------------------------------------------------------------------------
	Aliases
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Default
-----------------------------------------------

/*
	Whenever we alter a column we see '(no column name)'

	Likewise if we return a simple value
*/

select 'String';


-----------------------------------------------
-- Column Alias
-----------------------------------------------

/*
	This is less than ideal, therefore we alias the output
*/

select 'String' as myColumn;


/*
	There are other ways to do this, but the above is best practice

	For completeness the following also works:
*/

select 'String' myColumn,
        myColumn = 'String';


/*
	We avoid the above because without AS it is not as clear and using = confuses with equations

	We have the same rules around special characters and spaces as covered in SELECT

	We use square brackets to deal with these
*/

select 'String' as [my column name];


/*
	These are also vital to help interpret our data for consumers
*/

select infoCol, infoCol as employeeName
from JupyterDatabase.sales.basicSales;


-----------------------------------------------
-- Table Alias
-----------------------------------------------

/*
	Tables can also be aliased

	We haven't done this yet as simple statements do not require it

	When used in JOINs and others syntaxes these will become essential

	We have seen the following
*/

select orderID, salesAmount
from JupyterDatabase.sales.basicSales;


/*
	Technically speaking we should write this as follows:
*/

select sales.basicSales.orderID, sales.basicSales.salesAmount
from JupyterDatabase.sales.basicSales;


/*
	This is excessive and therefore we can shorten this with an alias

	We use the same AS syntax that we met with column aliasing

	When using JOINs (which are coming up) we will see how this is essential

	If we have orderID coming from BOTH tables in a join, for example
		we need to tell SQL Server which table's column we wish to see
*/

select b.orderID, b.salesAmount
from JupyterDatabase.sales.basicSales as b;


-----------------------------------------------
-- Alias Limitations
-----------------------------------------------

/*
	There are some limitations that we need to consider

	We should always alias where needed, but taking these limitations into account

	We can use Table Aliases everywhere in a query
*/

select b.infoCol, b.customerTitle, b.customerFName, b.customerLName
from JupyterDatabase.sales.basicSales b
where b.orderID in (1, 3, 5)
order by b.orderID desc;


/*
	However, Column Aliases are trickier

	This query looks fine but will actually throw an error
*/

select b.orderID, concat_ws(' ', b.customerTitle, b.customerFName, b.customerLName) as fullName
from JupyterDatabase.sales.basicSales b
where fullName = 'Ms Anderson'
order by fullName desc;


/*
	Whereas this query executes just fine
*/

select b.orderID, concat_ws(' ', b.customerTitle, b.customerFName, b.customerLName) as fullName
from JupyterDatabase.sales.basicSales b
where concat_ws(' ', b.customerTitle, b.customerFName, b.customerLName) = 'Ms Anderson'
order by fullName desc;
