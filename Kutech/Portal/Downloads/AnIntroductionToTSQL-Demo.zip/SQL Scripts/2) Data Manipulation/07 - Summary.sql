/*------------------------------------------------------------------------------------
	Summary
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Required Report
-----------------------------------------------

/*
	Using a table called �sales.basicSales� obtain:
		Year of Order
		Day of week the order was taken
		Employee Name
		Customer�s Full Name
		Total Order Value (sale amount + tax)
	Note - All columns should be given appropriate headings
*/

-- Year of Order

select datepart(yy, orderDate) orderYear
from JupyterDatabase.sales.basicSales;


-- Day of Week the order was taken

select case datepart(dw, orderDate)
			when 1 then 'Sunday'
			when 2 then 'Monday'
			when 3 then 'Tuesday'
			when 4 then 'Wednesday'
			when 5 then 'Thursday'
			when 6 then 'Friday'
		else 'Saturday' end as [dayOfWeek]
from JupyterDatabase.sales.basicSales;


-- Employee Name

select substring(infoCol, charindex(': ', infoCol, 1) + 2, len(infoCol)) as employeeName
from JupyterDatabase.sales.basicSales;


-- Customer's Full Name

select concat_ws(' ', customerTitle, customerFName, customerLName) customerFullName
from JupyterDatabase.sales.basicSales;


-- Total Order Value (sale amount + tax)

select (salesAmount + taxAmount) as totalSalesAmount
from JupyterDatabase.sales.basicSales;


-- Putting it all together

select datepart(yy, orderDate) orderYear,
		case datepart(dw, orderDate)
			when 1 then 'Sunday'
			when 2 then 'Monday'
			when 3 then 'Tuesday'
			when 4 then 'Wednesday'
			when 5 then 'Thursday'
			when 6 then 'Friday'
		else 'Saturday' end as [dayOfWeek],
		substring(infoCol, charindex(': ', infoCol, 1) + 2, len(infoCol)) as employeeName,
		concat_ws(' ', customerTitle, customerFName, customerLName) customerFullName,
		(salesAmount + taxAmount) as totalSalesAmount
from JupyterDatabase.sales.basicSales;

