/*------------------------------------------------------------------------------------
	Basic Aggregation
------------------------------------------------------------------------------------*/

/*
	We will use a new table for this demo
*/

select *
from JupyterDatabase.dbo.testScores;


-----------------------------------------------
-- SUM
-----------------------------------------------

select sum(scoreValue)
from JupyterDatabase.dbo.testScores;


/*
	We must sum a column

	Summing * will not work and will throw an error
*/

select sum(*)
from JupyterDatabase.dbo.testScores;


/*
	We can add WHERE clauses etc as expected
*/

select sum(scoreValue)
from JupyterDatabase.dbo.testScores
where scoreValue > 1;


-----------------------------------------------
-- COUNT
-----------------------------------------------

select count(*)
from JupyterDatabase.dbo.testScores;


/*
	With COUNT we CAN use distinct if we wish to count non duplicates
*/

select scoreValue
from JupyterDatabase.dbo.testScores;


select count(distinct scoreValue)
from JupyterDatabase.dbo.testScores;


-----------------------------------------------
-- AVERAGE
-----------------------------------------------

/*
	We have our sum of 36 and count of 6, therefore let's test Average
*/

select avg(scoreValue)
from JupyterDatabase.dbo.testScores;


-----------------------------------------------
-- MIN and MAX
-----------------------------------------------

select min(scoreValue)
from JupyterDatabase.dbo.testScores;

select max(scoreValue)
from JupyterDatabase.dbo.testScores;
go


-----------------------------------------------
-- Combination of Aggregates
-----------------------------------------------

/*
	We can use as many as we like within our query
*/

select min(scoreValue), max(scoreValue),
        count(scoreValue), count(distinct scoreValue),
        sum(scoreValue), avg(scoreValue)
from JupyterDatabase.dbo.testScores;
