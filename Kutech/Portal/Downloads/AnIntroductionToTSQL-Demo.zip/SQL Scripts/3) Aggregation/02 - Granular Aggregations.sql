/*------------------------------------------------------------------------------------
	Granular Aggregation
------------------------------------------------------------------------------------*/

/*
	We will use another new table for this demo
*/

select top (10) *
from JupyterDatabase.sales.salesOrderHeader;


/*
	We are only interested in a few columns
*/

select top (10) salesPersonID, orderDate, totalDue
from JupyterDatabase.sales.salesOrderHeader;


/*
	Let's do a quick row count
*/

select count(*)
from JupyterDatabase.sales.salesOrderHeader;


-----------------------------------------------
-- GROUP BY
-----------------------------------------------

/*
	We can group our aggregations using GROUP BY

	Let's GROUP BY salesPersonID
*/

select sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
group by salesPersonID;


/*
	This is great except we cannot see the salesPersonID against each group

	So we shall add that to the SELECT line
*/

select salesPersonID, sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
group by salesPersonID;


/*
	We could also GROUP BY year using the same method
*/

select year(orderDate) as orderYear, sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
group by year(orderDate);


/*
	Non-aggregated columns MUST appear in a GROUP BY clause to avoid error
*/

select salesPersonID, sum(totalDue) as totalSales -- Column is selected (salesPersonID) and Aggregate is used (SUM(totalDue))
from JupyterDatabase.sales.salesOrderHeader; -- Note, no GROUP BY clause will result in error


/*
	We can GROUP BY multiple columns at the same time
*/

select month(orderDate) as orderMonth, salesPersonID, sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
group by month(orderDate), salesPersonID;


/*
	We can add a WHERE clause above the GROUP BY (as it happens first)
*/

select month(orderDate) as orderMonth, salesPersonID, sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
where orderDate between '2018-01-01' and '2018-12-31 23:59:59.995'
group by month(orderDate), salesPersonID;


/*
	We are also allowed to ORDER BY results

	Noting that we CAN use aliases for our ORDER BY
*/

select month(orderDate) as orderMonth, salesPersonID, sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
where orderDate between '2018-01-01' and '2018-12-31'
group by month(orderDate), salesPersonID
order by orderMonth, salesPersonID;


/*
	How do we filter an aggregated value though?

	Can we use WHERE?
*/

select month(orderDate) as orderMonth, salesPersonID, sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
where orderDate between '2018-01-01' and '2018-12-31'
and sum(totalSales) > 150000
group by month(orderDate), salesPersonID
order by orderMonth, salesPersonID;


-----------------------------------------------
-- HAVING
-----------------------------------------------

/*
	This is a filter post-aggregation

	We place this after the GROUP BY
*/

select month(orderDate) as orderMonth, salesPersonID, sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
where orderDate between '2018-01-01' and '2018-12-31'
group by month(orderDate), salesPersonID
having sum(totalDue) > 150000
order by orderMonth, salesPersonID;

