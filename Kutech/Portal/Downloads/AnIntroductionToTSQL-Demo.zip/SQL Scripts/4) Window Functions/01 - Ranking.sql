/*------------------------------------------------------------------------------------
	Window Functions - Ranking
------------------------------------------------------------------------------------*/

/*
	We will use another new table for this demo
*/

select *
from JupyterDatabase.sales.salesOrderHeaderWindow;


-----------------------------------------------
-- ROW_NUMBER
-----------------------------------------------

/*
	This simply appends an auto incrementing ID column
*/

select row_number() over(order by orderDate) id, *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	We place our ORDER BY clause in the OVER section

	This defines the order of the ID

	In the above it was orderDate, below we will do saleAmount desc
*/

select row_number() over(order by saleAmount desc) id, *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	We can override this in the presentation layer
		Order our ID by one thing, the output by another
*/

select row_number() over(order by saleAmount desc) id, *
from JupyterDatabase.sales.salesOrderHeaderWindow
order by orderDate;


/*
	PARTITION BY allows us to define groups

	For example:
		Get the data for the first SalesPersonID
			Add a row_number to this data
		Get the data for the second SalesPersonID
			Add a row_number to this data
		etc.
*/

select row_number() over(partition by salesPersonID order by orderDate) id, *
from JupyterDatabase.sales.salesOrderHeaderWindow;


-----------------------------------------------
-- RANK
-----------------------------------------------

/*
	This RANKs the data
	
	It skips as a result of a tie
*/

select rank() over(order by orderDate), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	We can also PARTITION this in the same way as row_number

	THis will start the RANK again for each SalesPersonID
*/

select rank() over(partition by salesPersonID order by orderDate), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


-----------------------------------------------
-- DENSE_RANK
-----------------------------------------------

/*
	This also RANKs the data
	
	It does NOT skip as a result of a tie

	It can also PARTITION
*/

select dense_rank() over(order by orderDate), *
from JupyterDatabase.sales.salesOrderHeaderWindow;

select dense_rank() over(partition by salesPersonID order by orderDate), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


-----------------------------------------------
-- NTILE
-----------------------------------------------

/*
	Breaks our data into percentiles, quartiles, deciles etc

	We have 10 records, so we will use NTILE(2) to split our data into 'top half' and 'bottom half'
*/

select ntile(2) over(order by saleAmount), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	We can also PARTITION this data

	This will perform the NTILE for each PARTITION

	We will use NTILE(3) for this demo

	We have 3 records for SalesPersonID 44
		Each record will be in its own TILE
	We have 7 records for SalesPersonID 51
		We will get 3-2-2 in each TILE respectively
			SQL always adds more to the first TILE(s)
*/

select ntile(3) over(partition by salesPersonID order by saleAmount), *
from JupyterDatabase.sales.salesOrderHeaderWindow;
