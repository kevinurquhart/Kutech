/*------------------------------------------------------------------------------------
	Window Functions - Aggregates
------------------------------------------------------------------------------------*/

/*
	These create an aggregate of the data and then apply that aggregate to each row
*/

-----------------------------------------------
-- MIN
-----------------------------------------------

/*
	We know from GROUP BY that MIN returns a single minimum value for a dataset
*/

select min(saleAmount)
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	With a Window Function we obtain the same data, but without compressing the data
*/

select min(saleAmount) over(order by saleAmount), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	We can also PARTITION the data to return the MIN for each PARTITION (SalesPersonID)
*/

select min(saleAmount) over(partition by salesPersonID), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	HOWEVER, there's a potential catch
*/

select min(saleAmount) over(order by saleAmount desc), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	We now have the 'incorrect' data

	However, it is what we have asked for

	SQL Server reads from top to bottom, record by record, to obtain the aggregate value

	We need to 'frame' our data by telling SQL Server
		This is our data
		For each PARTITION read in this direction from the current row

	To fix our problem above we need to tell SQL Server
		We need the MIN over the entire dataset
		We have presented the data 'backwards' from max to min
		Therefore read from current row to the end of the 'frame' to get the MIN value
*/

select min(saleAmount)
		over
		(
			order by saleAmount desc
			rows between current row and unbounded following
		), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	We have 3 framing options:
		rows between current row and unbounded following
		rows between unbounded preceding and current row
		rows between unbounded preceding and unbounded following
*/


-----------------------------------------------
-- MAX
-----------------------------------------------

/*
	This works in exactly the same way as MIN, but for MAX

	We shall be explicit in our framing for clarity
		Relying on defaults can catch you out
*/

select max(saleAmount)
		over
		(
			order by saleAmount
			rows between unbounded preceding and unbounded following
		), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	We can PARTITION as expected

	We will PARTITION on SalesPersonID
*/

select max(saleAmount)
		over
		(
			partition by salesPersonID
			order by saleAmount
			rows between unbounded preceding and unbounded following
		), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


-----------------------------------------------
-- COUNT
-----------------------------------------------

/*
	This works in exactly the same way as MIN and MAX
*/

select count(saleAmount)
		over
		(
			order by saleAmount
			rows between unbounded preceding and unbounded following
		), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	With a PARTITION
*/

select count(saleAmount)
		over
		(
			partition by salesPersonID
			order by saleAmount
			rows between unbounded preceding and unbounded following
		), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


-----------------------------------------------
-- AVG
-----------------------------------------------

/*
	This CAN work in exactly the same way as MIN, MAX, and COUNT
*/

select avg(saleAmount)
		over
		(
			order by saleAmount
			rows between unbounded preceding and unbounded following
		), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	With a PARTITION
*/

select avg(saleAmount)
		over
		(
			partition by salesPersonID
			order by saleAmount
			rows between unbounded preceding and unbounded following
		), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	HOWEVER, AVG has a special feature

	Using it without a 'frame' means it takes each record as it comes
		(This uses the default frame of "rows between unbounded preceding and current row")

	This provides a rolling average
*/

select avg(saleAmount)
		over
		(
			partition by salesPersonID
			order by orderDate
		), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


-----------------------------------------------
-- SUM
-----------------------------------------------

/*
	As with AVG, this can work the same as MIN etc, but also can provide a running total

	Firstly we'll provide the total over a frame
*/

select sum(saleAmount)
		over
		(
			order by saleAmount
			rows between unbounded preceding and unbounded following
		), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	Including at the PARTITION level
*/

select sum(saleAmount)
		over
		(
			partition by salesPersonID
			order by saleAmount
			rows between unbounded preceding and unbounded following
		), *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	We can also create a rolling total
*/

select sum(saleAmount)
		over
		(
			partition by salesPersonID
			order by orderDate
		), *
from JupyterDatabase.sales.salesOrderHeaderWindow;

