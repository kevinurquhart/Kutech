/*------------------------------------------------------------------------------------
	Window Functions - Value Based
------------------------------------------------------------------------------------*/

/*
	These are neither Ranking or Aggregate functions

	They simply highlight key values within your data
*/

-----------------------------------------------
-- FIRST_VALUE
-----------------------------------------------

/*
	This shows the first value seen in the dataset against all other rows

	Good for "value of first order against all following sales"
*/

select first_value(saleAmount) over(order by orderDate), *
from JupyterDatabase.sales.salesOrderHeaderWindow
where salesPersonID = 51;


-----------------------------------------------
-- LAST_VALUE
-----------------------------------------------

/*
	This shows the last value seen in the dataset against all other rows

	Good for "value of latest order against all other sales"

	Note, to see this we need to 'frame' our data accordingly
*/

select last_value(saleAmount)
		over
		(
			order by orderDate
			rows between unbounded preceding and unbounded following
		), *
from JupyterDatabase.sales.salesOrderHeaderWindow
where salesPersonID = 51;


-----------------------------------------------
-- LEAD
-----------------------------------------------

/*
	LEAD provides an offset ability without performing a JOIN to another table

	We have our basic data
*/

select *
from JupyterDatabase.sales.salesOrderHeaderWindow
where salesPersonID = 44
order by orderDate;


/*
	Let's place each order against the one from the following day

	To do this we tell SQL Server to offset the salesAmount by 1
*/

select *, lead(saleAmount, 1) over(order by orderDate)
from JupyterDatabase.sales.salesOrderHeaderWindow
where salesPersonID = 44
order by orderDate;


/*
	We can offset by any number of days (depending on size of dataset)

	In this case we can offset by 2 days
*/

select *, lead(saleAmount, 2) over(order by orderDate)
from JupyterDatabase.sales.salesOrderHeaderWindow
where salesPersonID = 44
order by orderDate;


-----------------------------------------------
-- LAG
-----------------------------------------------

/*
	This is the same as LEAD except it looks backwards instead of forwards
*/

select *, lag(saleAmount, 1) over(order by orderDate)
from JupyterDatabase.sales.salesOrderHeaderWindow
where salesPersonID = 44
order by orderDate;


select *, lag(saleAmount, 2) over(order by orderDate)
from JupyterDatabase.sales.salesOrderHeaderWindow
where salesPersonID = 44
order by orderDate;


