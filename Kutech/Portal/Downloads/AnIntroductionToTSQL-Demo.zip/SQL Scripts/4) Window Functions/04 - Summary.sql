/*------------------------------------------------------------------------------------
	Window Functions - Reports
------------------------------------------------------------------------------------*/

/*
	Report One
		Add an Identity column to our table as a whole ordered by order date then salesPersonID
		Secondary Identity for each employee ordered by saleAmount (largest to smallest)
	Report Two
		Add a column providing a cumulative sales total per salesPersonID
	Report Three
		Add a column showing the total saleAmount per salesPersonID
		Add columns showing the first and last saleAmount for each SalesPersonID
*/


-----------------------------------------------
-- Report One
-----------------------------------------------

/*
	First we need a ranking function for the identity
*/

select row_number() over(order by orderDate, salesPersonID) as myIdentityColumn, *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	Secondly we need a partitioned row_number
*/

select row_number()
		over
		(
			partition by salesPersonID
			order by saleAmount desc
		) as mySecondaryIdentityColumn, *
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	Putting these together
*/

select row_number() over(order by orderDate, salesPersonID) as myIdentityColumn,
		row_number()
		over
		(
			partition by salesPersonID
			order by saleAmount desc
		) as mySecondaryIdentityColumn, *
from JupyterDatabase.sales.salesOrderHeaderWindow
order by myIdentityColumn;


-----------------------------------------------
-- Report Two
-----------------------------------------------

/*
	Cumulative Sales means SUM using a default frame
*/

select *, sum(saleAmount)
            over
            (
                partition by salesPersonID
                order by salesPersonID, orderDate
            ) as runningSalesTotal
from JupyterDatabase.sales.salesOrderHeaderWindow;


-----------------------------------------------
-- Report Three
-----------------------------------------------

/*
	Total sales for each sales person

	This means a SUM but with a 'frame'

	Partitioned by salesPersonID
*/

select *, sum(saleAmount)
			over
			(
				partition by salesPersonID
				order by orderDate
				rows between unbounded preceding and unbounded following
			) as totalSales
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	We need first and last values for each salesPersonID

	We will need a 'frame' and PARTITION BY
*/

select *, first_value(saleAmount)
			over
			(
				partition by salesPersonID
				order by orderDate
				rows between unbounded preceding and unbounded following
			) as firstSale,
			last_value(saleAmount)
			over
			(
				partition by salesPersonID
				order by orderDate
				rows between unbounded preceding and unbounded following
			) as firstSale
from JupyterDatabase.sales.salesOrderHeaderWindow;


/*
	Combining these leaves us with the answer
*/

select *, first_value(saleAmount)
			over
			(
				partition by salesPersonID
				order by orderDate
				rows between unbounded preceding and unbounded following
			) as firstSale,
			last_value(saleAmount)
			over
			(
				partition by salesPersonID
				order by orderDate
				rows between unbounded preceding and unbounded following
			) as firstSale,
            sum(saleAmount)
			over
			(
				partition by salesPersonID
				order by orderDate
				rows between unbounded preceding and unbounded following
			) as totalSales
from JupyterDatabase.sales.salesOrderHeaderWindow;
