/*------------------------------------------------------------------------------------
	Normalisation
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Pre Normalisation
-----------------------------------------------

/*
	Looking at the following we can see how data might arrive
*/

select *
from JupyterDatabase.dbo.preNormalised;


/*
	Imagine the issues around altering a department of "Store" to "Shop"

	Many records to update

	Mistakes could happen if done incorrectly
*/

select *
from JupyterDatabase.dbo.preNormalised
where department = 'Store';


/*
	Likewise a change in jobTitle or jobGrade
*/


-----------------------------------------------
-- Post Normalisation
-----------------------------------------------

/*
	Once normalised we are left with more tables and ID columns

	But the data is considerably more manageable
*/

select *
from JupyterDatabase.hr.employee;

select *
from JupyterDatabase.hr.jobTitle;

select *
from JupyterDatabase.hr.department;


/*
	Consider now changing "Store" to "Shop"
*/

select *
from JupyterDatabase.hr.department;


/*
	One solitary change of value and all employees are automatically updated
*/
