/*------------------------------------------------------------------------------------
	Common Joins
------------------------------------------------------------------------------------*/

/*
	We shall use the following tables
*/

select *
from hr.employeeSmall;

select *
from sales.salesOrderHeaderSmall;


-----------------------------------------------
-- INNER JOIN
-----------------------------------------------

/*
	We shall first obtain just Employee data remembering to use our alias
*/

select e.employeeID, e.firstName, e.lastName
from JupyterDatabase.hr.employeeSmall as e;


/*
	Now we can JOIN our SalesOrderHeaderSmall table on their common column, employeeID

	This only returns data where the same EmployeeID resides in both tables
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
inner join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID;


-----------------------------------------------
-- LEFT JOIN
-----------------------------------------------

/*
	This returns the whole of the FROM table

	Only returns matches from the JOIN table
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
left join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID;


-----------------------------------------------
-- RIGHT JOIN
-----------------------------------------------

/*
	This returns the whole of the JOIN table

	Only returns matches from the FROM table

	This can be written as a LEFT JOIN if reversed
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
right join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID;


-----------------------------------------------
-- FULL OUTER JOIN
-----------------------------------------------

/*
	This returns the whole of the FROM table

	AND the whole of the JOIN table

	Non matches appear on both sides as NULL
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
full join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID;


-----------------------------------------------
-- USAGE IN REPORTS
-----------------------------------------------

/*
	Report One
		Full Name of any employee who has not made any sales
	Report Two
		In what year was the oldest employee to make sales born?
	Report Three
		What is the total value of sales for which we have no employee information present
*/


-----------------------------------------------
-- REPORT ONE
-----------------------------------------------

/*
	Full Name of any employee who has not made any sales

	This can be read as
		Get all Employees
		LEFT JOIN to Sales
		Remove anything with NULL sales (they haven't had any)

	Let's start with the LEFT JOIN
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
left join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID;


/*
	Now let's add our WHERE clause
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
left join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID
where s.employeeID is null;


/*
	Finally, we required a Full Name
*/

select concat_ws(' ', e.title, e.firstName, e.lastName) as fullName
from JupyterDatabase.hr.employeeSmall as e
left join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID
where s.employeeID is null;


-----------------------------------------------
-- REPORT TWO
-----------------------------------------------

/*
	In what year was the oldest employee to make sales born?

	We only need employees with sales
		This is an INNER JOIN
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
inner join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID;


/*
	Now we need to ascertain the oldest

	We can do this with an aggregate using MIN and YEAR(dob)

	This gives us our answer
*/

select min(year(dob)) as minBirthYear
from JupyterDatabase.hr.employeeSmall as e
inner join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID;


-----------------------------------------------
-- REPORT THREE
-----------------------------------------------

/*
	What is the total value of sales for which we have no employee information present?

	We clearly need a LEFT or RIGHT join as we need "no employee information present"

	Let's use both just to show they are equivalents depending on the table order
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
left join JupyterDatabase.sales.salesOrderHeaderSmall s
on e.employeeID = s.employeeID;

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.sales.salesOrderHeaderSmall s
right join JupyterDatabase.hr.employeeSmall as e
on e.employeeID = s.employeeID;


/*
	For variety I'll use RIGHT JOIN as we used LEFT earlier
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
right join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID;


/*
	We now need only records where there is no employeeID (employeeID is null)

	And we need aggregate the sales using SUM
*/

select sum(s.totalDue) salesAmount
from JupyterDatabase.hr.employeeSmall as e
right join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID
where e.employeeID is null;
