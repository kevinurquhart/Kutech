/*------------------------------------------------------------------------------------
	Common Join Quirks
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Missing LEFT JOIN records
-----------------------------------------------

/*
	Let's look at our data from the last example
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
right join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID;


/*
	We can see that EmployeeID 45 does not appear in the Employee table

	He has 2 orders placed in November 2019
*/


-----------------------------------------------
-- Contrived Example
-----------------------------------------------

/*
	Show all employees
		First and last names
	Only show orders if they were placed in November 2019

	We can start with a LEFT JOIN
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
left join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID;


/*
	Now we can show only orders placed in November
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
left join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID
where month(s.orderDate) = 11;


/*
	Something's gone wrong?  We lost all our data?

	But we did a LEFT JOIN?

	Consider the Processing Order
		We do JOIN / ON / WHERE

	Therefore SQL Server first does this:
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
left join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID;


/*
	This is now our resulting table

	We therefore add a WHERE to filter these results

	This removes all records
*/


-----------------------------------------------
-- Solution
-----------------------------------------------

/*
	We effectively need to filter the JOIN table before we join

	Something like this:
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
left join
(
        select *
        from JupyterDatabase.sales.salesOrderHeaderSmall
        where month(orderDate) = 11
) as s
on e.employeeID = s.employeeID;


/*
	Thinking about Processing Order
		JOIN / ON / WHERE

	We could filter in the ON clause?
		Therefore saying "JOIN to this ON these filters"
*/

select e.employeeID, e.firstName, e.lastName,
		s.employeeID, s.orderDate
from JupyterDatabase.hr.employeeSmall as e
left join JupyterDatabase.sales.salesOrderHeaderSmall as s
on e.employeeID = s.employeeID
and month(s.orderDate) = 11;
