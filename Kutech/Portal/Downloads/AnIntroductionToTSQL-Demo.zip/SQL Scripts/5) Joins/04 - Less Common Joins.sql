/*------------------------------------------------------------------------------------
	Less Common Joins
------------------------------------------------------------------------------------*/

/*
	We shall use the following tables
*/

select *
from JupyterDatabase.sales.salesOrderHeaderSmall;

select *
from JupyterDatabase.sales.salesOrderHeaderSmall2;

-----------------------------------------------
-- CROSS JOIN
-----------------------------------------------

/*
	This literally matches every row in the FROM to every row in the JOIN
*/

select a.employeeID, b.employeeID
from JupyterDatabase.hr.employeeSmall as a
cross join JupyterDatabase.hr.employeeSmall as b;


-----------------------------------------------
-- UNION ALL
-----------------------------------------------

/*
	We have slightly different data in our two tables

	UNION ALL simply stacks one dataset on top of another

	We have 10 and 8 records in our tables, therefore we should see 18
*/

select orderID, orderDate, salesOrderNo, customerID, employeeID, totalDue
from JupyterDatabase.sales.salesOrderHeaderSmall
union all
select orderID, orderDate, salesOrderNo, customerID, employeeID, totalDue
from JupyterDatabase.sales.salesOrderHeaderSmall2;


-----------------------------------------------
-- UNION
-----------------------------------------------

/*
	UNION does the same stacking as UNION ALL

	UNION removes any duplications in the output
*/

select orderID, orderDate, salesOrderNo, customerID, employeeID, totalDue
from JupyterDatabase.sales.salesOrderHeaderSmall
union
select orderID, orderDate, salesOrderNo, customerID, employeeID, totalDue
from JupyterDatabase.sales.salesOrderHeaderSmall2;


-----------------------------------------------
-- EXCEPT
-----------------------------------------------

/*
	EXCEPT compares two tables and highlights any differences

	Imagine Sales.SalesOrderHeaderSmall is our original dataset we are happy with
	Sales.SalesOrderHeaderSmall2 are our results following some logic changes

	We wish to know what differences, if any, have appeared

	We run EXCEPT twice
		Anything in HeaderSmall not in HeaderSmall2
		Anything in HeaderSmall2 not in HeaderSmall
*/

select orderID, orderDate, salesOrderNo, customerID, employeeID, totalDue
from sales.salesOrderHeaderSmall
except
select orderID, orderDate, salesOrderNo, customerID, employeeID, totalDue
from sales.salesOrderHeaderSmall2;

select orderID, orderDate, salesOrderNo, customerID, employeeID, totalDue
from sales.salesOrderHeaderSmall2
except
select orderID, orderDate, salesOrderNo, customerID, employeeID, totalDue
from sales.salesOrderHeaderSmall;


-----------------------------------------------
-- INTERSECT
-----------------------------------------------

/*
	INTERSECT also allows us to compare datasets

	It returns only data that is present and identical between both datasets
*/

select orderID, orderDate, salesOrderNo, customerID, employeeID, totalDue
from sales.salesOrderHeaderSmall
intersect
select orderID, orderDate, salesOrderNo, customerID, employeeID, totalDue
from sales.salesOrderHeaderSmall2;


-----------------------------------------------
-- Summary Queries
-----------------------------------------------

/*
	Query One
		I wish to see all orderIDs that have been placed without duplication
	Query Two
		Which employee IDs have made a sale in both tables
	Query Three
		Are there any Order Dates which are in sales.salesOrderHeaderSmall but not in sales.salesOrderHeaderSmall2
*/


-----------------------------------------------
-- Query One
-----------------------------------------------

/*
	I wish to see all orderIDs that have been placed without duplication

	ALL OrderIDs implies a UNION or UNION ALL

	No duplication leans us towards UNION
*/

select orderID
from JupyterDatabase.sales.salesOrderHeaderSmall
union
select orderID
from JupyterDatabase.sales.salesOrderHeaderSmall2;


-----------------------------------------------
-- Query Two
-----------------------------------------------

/*
	Which employee IDs have made a sale in both tables

	In both tables would be an INTERSECT
*/

select employeeID
from JupyterDatabase.sales.salesOrderHeaderSmall
intersect
select employeeID
from JupyterDatabase.sales.salesOrderHeaderSmall2;


-----------------------------------------------
-- Query Three
-----------------------------------------------

/*
	Are there any Order Dates which are in sales.salesOrderHeaderSmall but not in sales.salesOrderHeaderSmall2

	Comparison looking for records in one table and not another is EXCEPT
*/

select orderDate
from sales.salesOrderHeaderSmall
except
select orderDate
from sales.salesOrderHeaderSmall2;

