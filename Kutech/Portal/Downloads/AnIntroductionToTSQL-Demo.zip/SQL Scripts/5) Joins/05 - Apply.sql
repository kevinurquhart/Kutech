/*------------------------------------------------------------------------------------
	APPLY
------------------------------------------------------------------------------------*/

/*
	We shall use the following tables
*/

select *
from JupyterDatabase.hr.employeeSmall;

select *
from JupyterDatabase.sales.salesOrderHeaderSmall;

-----------------------------------------------
-- Scenario
-----------------------------------------------

/*
	We have the following scenario

	Return all Employees with Orders
	Return only the Employee information and SUM of sales

	In order to use the APPLY operator we can think a little differently

		Return all records from the hr.employeeSmall table
		For each record in the hr.employeeSmall table:
			Go to the sales.salesOrderHeaderSmall table
			SUM the sales for the employee
			Return the summed value
		Return the employee and the summed sales value

	Therefore we can use APPLY
*/

select e.employeeID, e.firstName, e.lastName, x.totalSales
from hr.employeeSmall as e
cross apply
(
	select sum(totalDue) as totalSales
	from sales.salesOrderHeaderSmall s
	where e.employeeID = s.employeeID
) as x;







