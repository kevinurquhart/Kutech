/*------------------------------------------------------------------------------------
	Subqueries
------------------------------------------------------------------------------------*/

/*
	We can write SQL statements in most places

	When we place a statement in a statement it is a subquery
*/

-----------------------------------------------
-- Subquery in SELECT
-----------------------------------------------

/*
	These can be placed in the SELECT line

	This is usually not advisable, but can be done

	Let's place the CEO's full name against every record:
*/

select employeeID, firstName, lastName,
		(
			select concat_ws(' ', firstName, lastName)
			from JupyterDatabase.hr.employee
			where managerID is null
		) as CEOFullName
from JupyterDatabase.hr.employee;


-----------------------------------------------
-- Subquery in WHERE
-----------------------------------------------

/*
	This is the much more common usage of the subquery

	It can help us make queries more dynamic

	Let's imagine the following:

	We wish to obtain a total sales value for any employee with jobTitleID 25

	We COULD write a manual IN statement, but there are a lot of values (leading to mistakes and taking time)
*/

select count(*)
from JupyterDatabase.hr.employee
where jobTitleID = 25;


/*
	But we know all these employeeIDs as we can easily find them
*/

select employeeID
from JupyterDatabase.hr.employee
where jobTitleID = 25;


/*
	So why not use this as the basis of our IN list?
*/

select SUM(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
where salesPersonID in
(
	select employeeID
	from JupyterDatabase.hr.employee
	where jobTitleID = 25
);


/*
	This now adapts to any employees added to or removed from the jobTitleID
*/


-----------------------------------------------
-- JOIN vs Subquery
-----------------------------------------------

/*
	In many cases a subquery could be written as a JOIN

	It is personal preference based on how your brain interprets queries and logic

	For example, the above could be written as:
*/

select SUM(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader as s
join JupyterDatabase.hr.employee as e
on s.salesPersonID = e.employeeID
where e.jobTitleID = 25;
