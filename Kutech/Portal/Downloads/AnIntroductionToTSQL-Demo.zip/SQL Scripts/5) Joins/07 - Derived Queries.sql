/*------------------------------------------------------------------------------------
	Derived Queries
------------------------------------------------------------------------------------*/

/*
	This is a variant of a Subquery

	It is written exclusively in the FROM clause

	It effectively substitues a table for a query
*/

-----------------------------------------------
-- Example
-----------------------------------------------

/*
	We wish to return the following:

	FROM hr.employee
		employeeID, firstName, lastName, salary, dob, managerID
	JOIN sales.salesOrderHeader
		each employeeID's total sales for 2018

	We could write this as a single JOIN using JOINs and Aggregates
*/

select e.employeeID, e.firstName, e.lastName, e.salary, e.dob,
		e.managerID, sum(s.totalDue) as totalSales
from JupyterDatabase.hr.employee as e
join JupyterDatabase.sales.salesOrderHeader as s
on e.employeeID = s.salesPersonID
where s.orderDate between '2018-01-01' and '2018-12-31 23:59:59.999'
group by e.employeeID, e.firstName, e.lastName, e.salary,
			e.dob, e.managerID;


/*
	However, this is painful to read and interpret

	The GROUP BY is long, the meaning is unclear

	Therefore we could write this as a Derived Query

	Firstly, we shall get the total sales per employee for 2018
*/

select salesPersonID, sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
where orderDate between '2018-01-01' and '2018-12-31 23:59:59.999'
group by salesPersonID;


/*
	This has a much nicer look and feel and is easy to read and interpret

	Now we can get our hr.employee table and join to our query above
*/

select e.employeeID, e.firstName, e.lastName, e.salary, e.dob,
		e.managerID, totalSales
from JupyterDatabase.hr.employee as e
join
(
	select salesPersonID, sum(totalDue) as totalSales
	from JupyterDatabase.sales.salesOrderHeader
	where orderDate between '2018-01-01' and '2018-12-31 23:59:59.999'
	group by salesPersonID
) as s
on e.employeeID = s.salesPersonID;


/*
	Again, this boils down to personal preference

	Some may find the above less clear, others may prefer it despite it being longer
*/
