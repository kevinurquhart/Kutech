/*------------------------------------------------------------------------------------
	Variables
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Basic Variables
-----------------------------------------------

/*
	Let's create a basic INTEGER variable
*/

declare @myID int;
go


/*
	This is no use unless we allocate it a value
*/

declare @myID int;

set @myID = 1;
go


declare @myID int;

select @myID = 1;
go


/*
	We can also allocate it a value as part of creation
*/

declare @myID int = 1;
go


-----------------------------------------------
-- Using Variables
-----------------------------------------------

/*
	Let's have a look at a simple table
*/

select *
from JupyterDatabase.sales.basicSales;


/*
	We can write a WHERE clause against it
*/

select *
from JupyterDatabase.sales.basicSales
where orderID = 7;


/*
	Replace the WHERE with a variable
*/

declare @orderID int = 7;

select *
from JupyterDatabase.sales.basicSales
where orderID = @orderID;
go


/*
	Variables can be re-assigned and reused
*/

declare @stringVariable varchar(100) = 'Fisher';

select *
from JupyterDatabase.sales.basicSales
where customerLName = @stringVariable;

select @stringVariable = 'Ann';

select *
from JupyterDatabase.sales.basicSales
where customerFName = @stringVariable;
go


-----------------------------------------------
-- Example Report Usage
-----------------------------------------------

/*
	Report One
		We wish to see all sales for the last 5 years
		We only wish to see the customer's full name and sales amount
	
	We keep getting requirements to change the above to 10 years or 15 years etc

	We can easily write this:
*/

select concat_ws(' ', customerTitle, customerFName, customerLName) customerFullName, salesAmount
from JupyterDatabase.sales.basicSales
where year(orderDate) between 2015 and 2020;

select year(orderDate) orderYear, sum(salesAmount) totalSales
from JupyterDatabase.sales.basicSales
where year(orderDate) between 2015 and 2020
group by year(orderDate);


/*
	However, this isn't easy to change for varying years

	This could lead to mistakes etc

	Therefore we can change this to use variables
*/

declare @startYear int = 2005,
		@endYear int = 2015;

select concat_ws(' ', customerTitle, customerFName, customerLName) customerFullName, salesAmount
from JupyterDatabase.sales.basicSales
where year(orderDate) between @startYear and @endYear;

select year(orderDate) orderYear, sum(salesAmount) totalSales
from JupyterDatabase.sales.basicSales
where year(orderDate) between @startYear and @endYear
group by year(orderDate);


-----------------------------------------------
-- Assigning in a Query
-----------------------------------------------

/*
	We can also assign a value to a variable as the result of a query
*/

declare @totalSales money;

select @totalSales = sum(salesAmount)
from JupyterDatabase.sales.basicSales;

select @totalSales;


/*
	Let's use this method to return the sales information for the sale with the highest value

	(This is contrived, but shows usage)
*/

declare @salesAmount money;

select @salesAmount = max(salesAmount)
from JupyterDatabase.sales.basicSales;

select *
from JupyterDatabase.sales.basicSales
where salesAmount = @salesAmount;
go


-----------------------------------------------
-- Variables and Batches
-----------------------------------------------

/*
	A variable only lasts for a Batch

	At termination of a Batch all variables are destroyed

	Therefore GO 'kills' a variable
*/

declare @totalSales money;

select @totalSales = sum(salesAmount)
from JupyterDatabase.sales.basicSales;

select @totalSales;
go

select @totalSales = sum(salesAmount)
from JupyterDatabase.sales.basicSales;

select @totalSales;
go
