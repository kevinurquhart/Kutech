/*------------------------------------------------------------------------------------
	Tables
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Basic Table Creation
-----------------------------------------------

/*
	A table must have the following:
		A table must have a Schema
		A table must have a unique name in the database
		A table must have at least one column
		All columns must be uniquely named within the table
		All columns must be allocated a datatype
		Each column is separated by a comma (the last column therefore not needing one)

	Let's create a basic table as follows:

		Table is to use the default 'dbo' schema
		Table is to be called 'myFirstTable'
		Two columns
			ID column which is an integer
			miscValue column which is a character column holding up to 50 characters

	(Ensure we drop it first just in case)
*/

drop table if exists dbo.myFirstTable
go

create table dbo.myFirstTable
(
    ID int,
    miscValue varchar(100)
);


/*
	Let's try another one:

		Table contains sales data
		Table to be called 'basicSalesNew'
		We require the following columns:
			OrderID which is an integer
			OrderDate which is date and time (eg. '2020-01-01 12:00:00)
			EmployeeName which is a string up to 50 characters in length
			CustomerFullName which is a string up to 75 characters in length
			SalesAmount which will be a decimal value up to 1,000,000 with the possibility of 4 decimal places
*/

drop table if exists sales.basicSalesNew
go

create table sales.basicSalesNew
(
    OrderID int,
    OrderDate datetime,
    EmployeeName varchar(50),
    CustomerFullName varchar(75),
    SalesAmount decimal(11, 4)
);


/*
	Now we can look at this and check it has created
*/

select *
from sales.basicSalesNew;

