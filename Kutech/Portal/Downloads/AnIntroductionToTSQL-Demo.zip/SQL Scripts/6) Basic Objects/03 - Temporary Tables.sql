/*------------------------------------------------------------------------------------
	Temporary Tables
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Basic Temporary Table Creation
-----------------------------------------------

/*
	A temporary table is the same as a 'user' table except defined with a #

	A temporary table has no schema

	Let's create a basic table as follows:

		Table is to be a temporary table
		Table is to be called 'myFirstTempTable'
		Two columns
			ID column which is an integer
			miscValue column which is a character column holding up to 50 characters

	(Ensure we drop it first just in case)
*/

drop table if exists #myFirstTempTable
go

create table #myFirstTempTable
(
    ID int,
    miscValue varchar(50)
)

select *
from #myFirstTempTable;


/*
	We can recreate our sales table in temporary form as well
*/


drop table if exists #basicSalesNew
go

create table #basicSalesNew
(
    OrderID int,
    OrderDate datetime,
    EmployeeName varchar(50),
    CustomerFullName varchar(75),
    SalesAmount decimal(11, 4)
);

select *
from #basicSalesNew;
go

-----------------------------------------------
-- Sample Usage (INSERT coming next module)
-----------------------------------------------

/*
	Let's look back to the demo for the Derived Query

	First we got our sales per SalesPersonID
*/

select salesPersonID, sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
where orderDate between '2018-01-01' and '2018-12-31 23:59:59.999'
group by salesPersonID;


/*
	Then we placed this into our query as follows:
*/

select e.employeeID, e.firstName, e.lastName, e.salary, e.dob,
		e.managerID, totalSales
from JupyterDatabase.hr.employee as e
join
(
	select salesPersonID, sum(totalDue) as totalSales
	from JupyterDatabase.sales.salesOrderHeader
	where orderDate between '2018-01-01' and '2018-12-31 23:59:59.999'
	group by salesPersonID
) as s
on e.employeeID = s.salesPersonID;


/*
	I did mention that temporary tables help here

	They allow us to break up queries into more "usable" chunks

	We can clean up our SQL, make it clearer, and test as we go more easily

	Let's take our aggregate:
*/

select salesPersonID, sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
where orderDate between '2018-01-01' and '2018-12-31 23:59:59.999'
group by salesPersonID;


/*
	Let's put this into a temporary table
	(Ignore the INSERT syntax, it's coming up next)
*/

create table #salesSummary
(
	salesPersonID int,
	totalSales decimal(10, 2)
)
insert into #salesSummary
select salesPersonID, sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
where orderDate between '2018-01-01' and '2018-12-31 23:59:59.999'
group by salesPersonID;


/*
	Now we have our sales data in a temporary table

	We can have a look at our data and check it's good

	This allows logic checking as we go...
*/

select *
from #salesSummary;


/*
	This also now makes our final query a lot nicer
*/

select e.employeeID, e.firstName, e.lastName, e.salary, e.dob,
		e.managerID, totalSales
from JupyterDatabase.hr.employee as e
join #salesSummary as s
on e.employeeID = s.salesPersonID;

