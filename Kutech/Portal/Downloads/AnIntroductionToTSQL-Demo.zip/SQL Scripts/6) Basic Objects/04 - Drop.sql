/*------------------------------------------------------------------------------------
	DROP
------------------------------------------------------------------------------------*/

/*
	Dropping a table that doesn't exist
*/

drop table bob
go

drop table #bob
go


/*
	We also cannot create twice

	First time is fine
*/

create table bob
(
	id int
)

create table #bob
(
	id int
)

/*
	Second time causes an error
*/

create table bob
(
	id int
)

create table #bob
(
	id int
)

/*
	Therefore we need a method that is re-runnable

	"If table exists, drop, else do nothing"
*/

-----------------------------------------------
-- Dropping a Table
-----------------------------------------------

/*
	This syntax has changed over time
*/

-- Pre 2016

if object_id('dbo.bob') is not null drop table dbo.bob
go

if object_id('tempDB..#bob') is not null drop table #bob
go

-- Post 2016

drop table if exists dbo.bob
go

drop table if exists #bob
go


-----------------------------------------------
-- Dropping Other things
-----------------------------------------------

/*
	This is the same as the above, but vary the keyword

	For example:
*/

-- Pre 2016

if object_id('dbo.bob') is not null drop table dbo.bob
if object_id('dbo.bob') is not null drop view dbo.bob
if object_id('dbo.bob') is not null drop function dbo.bob
if object_id('dbo.bob') is not null drop procedure dbo.bob
go

-- Post 2016

drop table if exists dbo.bob
drop view if exists dbo.bob
drop function if exists dbo.bob
drop procedure if exists dbo.bob
go
