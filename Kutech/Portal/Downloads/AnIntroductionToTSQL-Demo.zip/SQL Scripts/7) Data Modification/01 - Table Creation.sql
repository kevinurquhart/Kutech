/*------------------------------------------------------------------------------------
	Table Creation
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Basic Table Creation
-----------------------------------------------

/*
	We covered this in the previous module
*/

drop table if exists #myFirstTempTable;
go

create table #myFirstTempTable
(
    ID int,
    miscValue varchar(50)
);

select *
from #myFirstTempTable;


-----------------------------------------------
-- Identity Columns
-----------------------------------------------

/*
	We might want to add an auto incrementing column

	This will start at 1 and increment by 1
*/

drop table if exists #myFirstTempTable;
go

create table #myFirstTempTable
(
    ID int identity(1, 1),
    miscValue varchar(50)
);


/*
	Let's presume we wish our column to start at 1,000,000 and increment by 5 each time
*/

drop table if exists #myFirstTempTable;
go

create table #myFirstTempTable
(
    ID int identity(1000000, 5),
    miscValue varchar(50)
);


-----------------------------------------------
-- Default Values
-----------------------------------------------

/*
	Let's presume we have the following table
*/

drop table if exists #memberTable;
go

create table #memberTable
(
    memberNumber int identity(1000000, 5),
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(60),
    isActive bit
);


/*
	However, it was decided that all new members are active by default

	We therefore shouldn't need to fill this in

	We can add a default to set it to 1 when not passed in
*/

drop table if exists #memberTable;
go

create table #memberTable
(
    memberNumber int identity(1000000, 5),
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(60),
    isActive bit default(1)
);


/*
	You can also add a default after creation if necessary

	This allows you to name it nicely if required
*/

drop table if exists #memberTable;
go

create table #memberTable
(
    memberNumber int identity(1000000, 5),
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(60),
    isActive bit
);

alter table #memberTable
    add constraint df_isActiveMember
    default(1)
    for isActive;


-----------------------------------------------
-- Calculated Columns
-----------------------------------------------

/*
	We now have an almost complete table

	However, we have established that full name could be calculated

	Why should we always manually pass this in, risking error

	We can enforce a calculated column
*/

drop table if exists #memberTable;
go

create table #memberTable
(
    memberNumber int identity(1000000, 5),
    firstName varchar(25),
    lastName varchar(35),
    fullName as concat_ws(' ', firstName, lastName),
    isActive bit default(1)
);




