/*------------------------------------------------------------------------------------
	Inserting Data
------------------------------------------------------------------------------------*/

/*
	We will use the following table as our base
*/

drop table if exists #memberTable;
go

create table #memberTable
(
    memberNumber int,
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(60),
    isActive bit
);


-----------------------------------------------
-- Basic Insert
-----------------------------------------------

/*
	The most basic way is to simple pass data to a table
*/

drop table if exists #memberTable;
go

create table #memberTable
(
    memberNumber int,
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(60),
    isActive bit
);

insert into #memberTable
select 1, 'John', 'Smith', 'John Smith', 1;

select *
from #memberTable;


/*
	A more correct method is to specify the columns we are inserting into
*/

drop table if exists #memberTable;

create table #memberTable
(
    memberNumber int,
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(60),
    isActive bit
);

insert into #memberTable
(
    memberNumber, firstName, lastName, fullName, isActive
)
select 1, 'John', 'Smith', 'John Smith', 1;

select *
from #memberTable;


/*
	This also allows us to use muddled ordering (if our source is in a different order)
*/

drop table if exists #memberTable;

create table #memberTable
(
    memberNumber int,
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(60),
    isActive bit
);

insert into #memberTable
(
    memberNumber, lastName, firstName, fullName, isActive
)
select 1, 'Smith', 'John', 'John Smith', 1;

select *
from #memberTable;


-----------------------------------------------
-- Insert from another table
-----------------------------------------------

/*
	Often we are pulling data from another table rather than hard coding

	Let's have a look at some source data
*/

select firstName, lastName, CONCAT_WS(' ', firstName, lastName)
from JupyterDatabase.hr.employee
where employeeID <= 5;


/*
	We can add an identity value to it (we'll do this later and 'correctly' with IDENTITY)
*/

select row_number() over(order by firstName) as memberNumber,
        firstName, lastName, CONCAT_WS(' ', firstName, lastName) as fullName,
        1 as isActive
from JupyterDatabase.hr.employee
where employeeID <= 5;


/*
	We can now perform our insert
*/

drop table if exists #memberTable;

create table #memberTable
(
    memberNumber int,
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(60),
    isActive bit
);

insert into #memberTable
(
    memberNumber, firstName, lastName, fullName, isActive
)
select row_number() over(order by firstName) as memberNumber,
        firstName, lastName, CONCAT_WS(' ', firstName, lastName) as fullName,
        1 as isActive
from JupyterDatabase.hr.employee
where employeeID <= 5;

select *
from #memberTable;
