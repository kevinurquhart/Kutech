/*------------------------------------------------------------------------------------
	Inserting Data
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Identity Columns
-----------------------------------------------

/*
	We have this time got a table with a pre-defined IDENTITY column
*/

drop table if exists #memberTable;

create table #memberTable
(
    memberNumber int identity(1000000, 5),
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(60),
    isActive bit
);


/*
	Let's try to perform the same as we did before
*/

drop table if exists #memberTable;

create table #memberTable
(
    memberNumber int identity(1000000, 5),
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(60),
    isActive bit
);

insert into #memberTable
(
    memberNumber, firstName, lastName, fullName, isActive
)
select row_number() over(order by firstName) as memberNumber,
        firstName, lastName, CONCAT_WS(' ', firstName, lastName) as fullName,
        1 as isActive
from JupyterDatabase.hr.employee
where employeeID <= 5;


/*
	The error informs us we cannot insert into an IDENTITY column

	This makes sense as the purpose of the column is for SQL Server to control it

	It would also allow us to override the constraints (start value and increment) which we don't want

	So let's remove the row_number from our query
*/

drop table if exists #memberTable;

create table #memberTable
(
    memberNumber int identity(1000000, 5),
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(60),
    isActive bit
);

insert into #memberTable
(
    firstName, lastName, fullName, isActive
)
select firstName, lastName, CONCAT_WS(' ', firstName, lastName) as fullName,
        1 as isActive
from JupyterDatabase.hr.employee
where employeeID <= 5;

select *
from #memberTable;


-----------------------------------------------
-- Default Values
-----------------------------------------------

/*
	Now that we've dealt with IDENTITY values, let's look at defaults
*/

drop table if exists #memberTable;
go

create table #memberTable
(
    memberNumber int identity(1000000, 5),
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(60),
    isActive bit default(1)
);


/*
	We CAN insert into a default value column

	It's a default only if not already provided
*/

drop table if exists #memberTable;
go

create table #memberTable
(
    memberNumber int identity(1000000, 5),
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(60),
    isActive bit default(1)
);

insert into #memberTable
(
    firstName, lastName, fullName, isActive
)
select firstName, lastName, CONCAT_WS(' ', firstName, lastName) as fullName,
        0 as isActive
from JupyterDatabase.hr.employee
where employeeID <= 5;

select *
from #memberTable;


/*
	But, as a default, if we don't pass anything in, then it takes over
*/

drop table if exists #memberTable;
go

create table #memberTable
(
    memberNumber int identity(1000000, 5),
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(60),
    isActive bit default(1)
);

insert into #memberTable
(
    firstName, lastName, fullName
)
select firstName, lastName, CONCAT_WS(' ', firstName, lastName) as fullName
from JupyterDatabase.hr.employee
where employeeID <= 5;

select *
from #memberTable;


-----------------------------------------------
-- Calculated Columns
-----------------------------------------------

/*
	We use the table to define the values to be shown within the calculated column
*/

drop table if exists #memberTable;
go

create table #memberTable
(
    memberNumber int identity(1000000, 5),
    firstName varchar(25),
    lastName varchar(35),
    fullName as concat_ws(' ', firstName, lastName),
    isActive bit default(1)
);


/*
	For this reason we know that we cannot enter anything into this column

	But we can try anyway
*/

drop table if exists #memberTable;
go

create table #memberTable
(
    memberNumber int identity(1000000, 5),
    firstName varchar(25),
    lastName varchar(35),
    fullName as concat_ws(' ', firstName, lastName),
    isActive bit default(1)
);

insert into #memberTable
(
    firstName, lastName, fullName
)
select firstName, lastName, CONCAT_WS(' ', firstName, lastName) as fullName
from JupyterDatabase.hr.employee
where employeeID <= 5;

select *
from #memberTable;


/*
	Therefore we simply remove the column from our INSERT list and it works
*/

drop table if exists #memberTable;

create table #memberTable
(
    memberNumber int identity(1000000, 5),
    firstName varchar(25),
    lastName varchar(35),
    fullName as concat_ws(' ', firstName, lastName),
    isActive bit default(1)
);

insert into #memberTable
(
    firstName, lastName
)
select firstName, lastName
from JupyterDatabase.hr.employee
where employeeID <= 5;

select *
from #memberTable;
