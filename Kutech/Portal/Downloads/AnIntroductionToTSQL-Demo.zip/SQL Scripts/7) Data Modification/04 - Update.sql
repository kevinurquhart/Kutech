/*------------------------------------------------------------------------------------
	UPDATE
------------------------------------------------------------------------------------*/

/*
	We shall start with a simple table and just 10 rows of data
*/

drop table if exists #employeeData;
go

create table #employeeData
(
	employeeID int,
	firstName varchar(25),
	lastName varchar(35),
	dateOfBirth date,
	salary decimal(10, 2)
);

insert into #employeeData
(
	employeeID, firstName, lastName, dateOfBirth, salary
)
select employeeID, firstName, lastName, dob, salary
from JupyterDatabase.hr.employee
where employeeID <= 10;

select *
from #employeeData;

-----------------------------------------------
-- Basic Update
-----------------------------------------------

/*
	We wish to amend the employee's date of birth

	We shall change it using a hard coded value
*/

update #employeeData
set dateOfBirth = '1979-01-01'
where employeeID = 1;

-- Check on the data we've updated
select *
from #employeeData;


/*
	We can also reference columns within our table as a source

	Let's give a 10% payrise to employeeIDs 1, 2, 3
*/

update #employeeData
set salary = salary * 1.1
where employeeID <= 3;

select *
from #employeeData;


-----------------------------------------------
-- Update with an Alias
-----------------------------------------------

/*
	We can also write this syntax slightly differently using an Alias

	This actually makes the statement look more the form we're used to
*/

update e
set dateOfBirth = '1979-12-31'
-- select *
from #employeeData as e
where employeeID = 1;

select *
from #employeeData;


/*
	We will now use this syntax to amend our salaries again

	This time we will give variable bonuses depending on current salary
*/

update e
set salary = 
--select salary,
salary *
            (
                case when salary >= 1000000 then 1.05
                     when salary >= 500000 then 1.1
                     when salary >= 250000 then 1.15
                else 1.2 end
            )
from #employeeData as e
where employeeID <= 10;

select *
from #employeeData;


/*
	As you can see, this syntax is very familiar (we swap SELECT for UPDATE SET)

	Therefore it's easy to see how we can adapt this to incorporate JOINs

	We will do this shortly
*/
