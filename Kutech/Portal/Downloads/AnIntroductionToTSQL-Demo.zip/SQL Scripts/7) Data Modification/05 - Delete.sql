/*------------------------------------------------------------------------------------
	DELETE
------------------------------------------------------------------------------------*/

/*
	We shall start with that same simple table of 10 rows
*/

drop table if exists #employeeData;
go

create table #employeeData
(
	employeeID int,
	firstName varchar(25),
	lastName varchar(35),
	dateOfBirth date,
	salary decimal(10, 2)
);

insert into #employeeData
(
	employeeID, firstName, lastName, dateOfBirth, salary
)
select employeeID, firstName, lastName, dob, salary
from JupyterDatabase.hr.employee
where employeeID <= 10;

select *
from #employeeData;

-----------------------------------------------
-- Basic Delete
-----------------------------------------------

/*
	We shall delete employeeID 1
*/

delete from #employeeData
where employeeID = 1;

select *
from #employeeData;


-----------------------------------------------
-- Delete with an Alias
-----------------------------------------------

/*
	This has a very similar look and feel to UPDATE

	We simply swap SELECT for DELETE and leave the remaining query the same
*/

delete e
-- select *
from #employeeData as e
where employeeID in (3, 4, 5, 9);

select *
from #employeeData;

