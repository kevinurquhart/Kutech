/*------------------------------------------------------------------------------------
	Modify via JOINs
------------------------------------------------------------------------------------*/

/*
	Let's have a look at a couple of tables
*/

select employeeID, title, firstName, lastName, salary, jobTitleID
from JupyterDatabase.hr.employee;

select *
from JupyterDatabase.hr.jobTitle;

/*
	Let's put the employee data into a temporary table to allow us to update

	We don't want to change 'real' data for this demo
*/

drop table if exists #employeeData;
go

create table #employeeData
(
    employeeID int,
    title varchar(5),
    firstName varchar(25),
    lastName varchar(35),
    salary decimal(10, 2),
    jobTitleID int
);

insert into #employeeData
(
    employeeID, title, firstName, lastName, salary, jobTitleID
)
select employeeID, title, firstName, lastName, salary, jobTitleID
from JupyterDatabase.hr.employee;


-----------------------------------------------
-- UPDATE via JOIN
-----------------------------------------------

/*
	We have been told to increase the salary of all those with jobGrade 6 by 10%

	We COULD get a list manually and write an UPDATE per record but this is laborious

	Let's look at our data via a SELECT with a JOIN
*/

select e.employeeID, e.title, e.firstName, e.lastName, e.salary, j.jobGrade
from #employeeData as e
join JupyterDatabase.hr.jobTitle as j
on e.jobTitleID = j.jobTitleID
where j.jobGrade = 6;


/*
	This is what the salary data will look like once changed
*/

select e.salary, e.salary * 1.1
from #employeeData as e
join JupyterDatabase.hr.jobTitle as j
on e.jobTitleID = j.jobTitleID
where j.jobGrade = 6;


/*
	We can now convert this to an UPDATE statement
*/

update e
set e.salary = e.salary * 1.1				-- SELECT becomes UPDATE and SET
from #employeeData as e						-- Remainder of query remains unchanged
join JupyterDatabase.hr.jobTitle as j
on e.jobTitleID = j.jobTitleID
where j.jobGrade = 6;

-- Verify the results
select e.employeeID, j.jobGrade, e.salary
from #employeeData as e
join JupyterDatabase.hr.jobTitle as j
on e.jobTitleID = j.jobTitleID
where j.jobGrade = 6;


-----------------------------------------------
-- DELETE via JOIN
-----------------------------------------------

/*
	Using the same #employeeData table we can check some numbers
*/

-- How many records in the table
select count(*)
from #employeeData

-- How many records with jobGrade = 6
select count(*)
from #employeeData as e
join JupyterDatabase.hr.jobTitle as j
on e.jobTitleID = j.jobTitleID
where j.jobGrade = 6;


/*
	We have 224 records, 80 of which are jobGrade 6

	We wish to delete all people with jobGrade 6

	This should leave 144 records

	Simply change the SELECT to a DELETE
*/

delete e								-- SELECT becomes DELETE
from #employeeData as e					-- Remainder of query remains unchanged
join JupyterDatabase.hr.jobTitle as j
on e.jobTitleID = j.jobTitleID
where j.jobGrade = 6;

-- Verify the results
select count(*) as numJobGrade6
from #employeeData as e
join JupyterDatabase.hr.jobTitle as j
on e.jobTitleID = j.jobTitleID
where j.jobGrade = 6;

-- Final count of #employeeData
select count(*) as countMinusJobGRade6
from #employeeData;

