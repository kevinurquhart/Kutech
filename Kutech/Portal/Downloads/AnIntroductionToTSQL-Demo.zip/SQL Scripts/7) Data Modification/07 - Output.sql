/*------------------------------------------------------------------------------------
	OUTPUT
------------------------------------------------------------------------------------*/

/*
	This is a good way to log changes to a table as a result of a modification

	We will use the following table
*/

drop table if exists #employee;
go

create table #employee
(
    employeeID int identity(1234, 5),
    firstName varchar(25),
    lastName varchar(35)
);


-----------------------------------------------
-- OUTPUT with INSERT
-----------------------------------------------

/*
	This is easy enough to do, but we have no feedback from SQL Server as to the outcome
*/

insert into #employee(firstName, lastName)
select 'John', 'Smith';


/*
	This isn't helpful

	OUTPUT comes to our aid

	We can access two hidden tables:
		INSERTED
		DELETED

	For INSERT we only see the INSERTED table
*/

insert into #employee(firstName, lastName)
output inserted.employeeID  -- 'output the employeeID from the inserted table'
select 'Bob', 'Smith';


/*
	This now tells us we inserted a record that became employeeID 1

	We can return other fields as well
*/

insert into #employee(firstName, lastName)
output inserted.employeeID, inserted.firstName, inserted.lastName
select 'Fred', 'Smith';


-----------------------------------------------
-- OUTPUT with UPDATE
-----------------------------------------------

/*
	The exact same thing applies when we refer to UPDATES

	However, with an UPDATE we can see BOTH the INSERTED and DELETED tables
		Basically a 'before' and 'after'
*/

update e
set e.firstname = 'Jeff'
output deleted.employeeID as previousEmployeeID,
        deleted.firstName as previousFirstName,
        deleted.lastName as previousLastName,
        inserted.employeeID as newEmployeeID,
        inserted.firstName as newFirstName,
        inserted.lastName as newLastName
from #employee as e
where e.firstName = 'John'
and e.lastName = 'Smith';


-----------------------------------------------
-- OUTPUT with DELETE
-----------------------------------------------

/*
	With DELETE we can only access the DELETED table
*/

delete e
output deleted.employeeID as deletedEmployeeID,
        deleted.firstName as deletedFirstName,
        deleted.lastName as deletedLastName
from #employee as e
where e.firstName = 'Bob'
and e.lastName = 'Smith';


-----------------------------------------------
-- OUTPUT with INTO
-----------------------------------------------

/*
	This is great, but what if we want to track these?

	We can do so with INTO

	Let's reset our demo and create a new Audit table too
*/

drop table if exists #employee;
go

create table #employee
(
    employeeID int identity(1234, 5),
    firstName varchar(25),
    lastName varchar(35)
);

drop table if exists #employeeAudit;
go

create table #employeeAudit
(
    employeeID int,
    previousFirstName varchar(25),
    previousLastName varchar(35),
    newFirstName varchar(25),
    newLastName varchar(35),
    auditDate datetime default(current_timestamp)
);


/*
	We can now utilise the OUTPUT keyword to return our INSERTED and DELETED information to our Audit table
*/

-- INSERT a record, logging this out to our archive table
insert into #employee(firstName, lastName)
output inserted.employeeID, inserted.firstName, inserted.lastName
into #employeeAudit(employeeID, newFirstName, newLastName)
select 'John', 'Smith';

-- Validate results
select *
from #employee;

select *
from #employeeAudit;


/*
	Let's now remove that record
*/

delete e
output deleted.employeeID, deleted.firstName, deleted.lastName
into #employeeAudit(employeeID, previousFirstName, previousLastName)
from #employee as e
where e.firstName = 'John'
and e.lastName = 'Smith';

-- Validate results
select *
from #employee;

select *
from #employeeAudit;


/*
	To show a full audit we will now rest again
*/

drop table if exists #employee;
go

create table #employee
(
    employeeID int identity(1234, 5),
    firstName varchar(25),
    lastName varchar(35)
);

drop table if exists #employeeAudit;
go

create table #employeeAudit
(
    employeeID int,
    previousFirstName varchar(25),
    previousLastName varchar(35),
    newFirstName varchar(25),
    newLastName varchar(35),
    auditDate datetime default(current_timestamp)
);


/*
	We can now do the following:
		INSERT a record
		UPDATE the record
		DELETE the record
*/

-- INSERT a record, logging this out to our archive table
insert into #employee(firstName, lastName)
output inserted.employeeID, inserted.firstName, inserted.lastName
into #employeeAudit(employeeID, newFirstName, newLastName)
select 'John', 'Smith';

-- UPDATE a record, logging this out to our archive table
update e
set e.firstName = 'Fred'
output inserted.employeeID, deleted.firstName, deleted.lastName,
        inserted.firstName, inserted.lastName
into #employeeAudit
(
    employeeID, previousFirstName, previousLastName,
    newFirstName, newLastName
)
from #employee as e
where e.firstName = 'John'
and e.lastName = 'Smith';

-- DELETE a record, logging this out to our archive table
delete e
output deleted.employeeID, deleted.firstName, deleted.lastName
into #employeeAudit(employeeID, previousFirstName, previousLastName)
from #employee as e
where e.firstName = 'Fred'
and e.lastName = 'Smith';

-- Validate results
select *
from #employee;

select *
from #employeeAudit;
