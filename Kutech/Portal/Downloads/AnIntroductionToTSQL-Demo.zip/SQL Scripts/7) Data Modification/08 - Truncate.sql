/*------------------------------------------------------------------------------------
	TRUNCATE
------------------------------------------------------------------------------------*/

/*
	This is the fastest way to empty a table completely
*/

drop table if exists #employee;

create table #employee
(
    employeeID int,
    firstName varchar(25),
    lastName varchar(35),
    dateOfBirth date,
    salary decimal(10, 2)
);

insert into #employee
(
    employeeID, firstName, lastName, dateOfBirth, salary
)
select employeeID, firstName, lastName, dob, salary
from JupyterDatabase.hr.employee;

-- Check we have data
select count(*)
from #employee;


/*
	Now we TRUNCATE
*/

-- TRUNCATE the table
truncate table #employee;

-- Check the table
select count(*)
from #employee;


