/*------------------------------------------------------------------------------------
	Summary
------------------------------------------------------------------------------------*/

/*
	We have the following requests:

	Query One

		Create a temporary table called #staffInfo to hold employeeID, firstName, lastName, a calculated fullName, jobTitle, salary, salesTotal
		Populate with employee data for those with a firstName beginning with B or P
		Employees must have had sales

	Query Two

		Delete from #staffInfo where employee was born before 1970

	Query Three

		Create an empty copy of the #staffInfo table called #staffAudit
		Give all remaining staff a 10% raise in salary
		Keep an audit of their previous salaries #staffAudit
*/

-----------------------------------------------
-- Query One
-----------------------------------------------

/*
	Firstly we'll create a temp table with the most appropriate datatypes
*/

drop table if exists #staffInfo;
go

create table #staffInfo
(
    employeeID int,
    firstName varchar(25),
    lastName varchar(35),
    fullName as concat_ws(' ', firstName, lastName),
    jobTitle varchar(50),
    salary decimal(10, 2),
    salesTotal decimal(10, 2)
);


/*
	Let's obtain all employees with firstNames beginning with B or P
*/

select employeeID, firstName, lastName, jobTitleID, salary
from JupyterDatabase.hr.employee
where firstName like 'B%'
or firstName like 'P%';


/*
	JOIN to get the jobTitle
*/

select e.employeeID, e.firstName, e.lastName, t.jobTitle, e.salary
from JupyterDatabase.hr.employee as e
join JupyterDatabase.hr.jobTitle as t
on e.jobTitleID = t.jobTitleID
where e.firstName like 'B%'
or e.firstName like 'P%';


/*
	Add a JOIN for those who have sales (we need those with sales only, therefore INNER JOIN)
*/

select e.employeeID, e.firstName, e.lastName, t.jobTitle, e.salary, sum(s.totalDue) as totalSales
from JupyterDatabase.hr.employee as e
join JupyterDatabase.hr.jobTitle as t
on e.jobTitleID = t.jobTitleID
join JupyterDatabase.sales.salesOrderHeader as s
on e.employeeID = s.salesPersonID
where e.firstName like 'B%'
or e.firstName like 'P%'
group by e.employeeID, e.firstName, e.lastName, t.jobTitle, e.salary;


/*
	Now we can perform the INSERT
*/

insert into #staffInfo
(
    employeeID, firstName, lastName, jobTitle, salary, salesTotal
)
select e.employeeID, e.firstName, e.lastName, t.jobTitle, e.salary, sum(s.totalDue) as totalSales
from JupyterDatabase.hr.employee as e
join JupyterDatabase.hr.jobTitle as t
on e.jobTitleID = t.jobTitleID
join JupyterDatabase.sales.salesOrderHeader as s
on e.employeeID = s.salesPersonID
where e.firstName like 'B%'
or e.firstName like 'P%'
group by e.employeeID, e.firstName, e.lastName, t.jobTitle, e.salary;

-- Check the results
select *
from #staffInfo;


-----------------------------------------------
-- Query Two
-----------------------------------------------

/*
	Now we need to DELETE anyone born before 1970

	To get DOB we need to JOIN back to hr.employee
*/

select s.*, e.dob
from #staffInfo as s
join JupyterDatabase.hr.employee as e
on s.employeeID = e.employeeID
where e.dob < '1970-01-01';


/*
	We can switch the SELECT to a DELETE
*/

delete s
from #staffInfo as s
join JupyterDatabase.hr.employee as e
on s.employeeID = e.employeeID
where e.dob < '1970-01-01';

-- Check the results
select *
from #staffInfo;


-----------------------------------------------
-- Query Three
-----------------------------------------------

/*
	We have 3 staff members left

	These need to have a 10% raise

	This is a basic UPDATE

	But we need to audit the change

	We shall create an Audit table
*/

drop table if exists #staffAudit;
go

create table #staffAudit
(
    employeeID int,
    firstName varchar(25),
    lastName varchar(35),
    fullName as concat_ws(' ', firstName, lastName),
    jobTitle varchar(50),
    salary decimal(10, 2),
    salesTotal decimal(10, 2),
    auditDateTime datetime default(current_timestamp)
);


/*
	We use OUTPUT INTO in order to log via our basic UPDATE
*/

update s
set s.salary = s.salary * 1.1
output deleted.employeeID, deleted.firstName, deleted.lastName,
        deleted.jobTitle, deleted.salary, deleted.salesTotal
into #staffAudit
(
    employeeID, firstName, lastName, jobTitle, salary, salesTotal
)
from #staffInfo as s;

-- Check the results
select *
from #staffInfo;

-- Check the audit table
select *
from #staffAudit;

