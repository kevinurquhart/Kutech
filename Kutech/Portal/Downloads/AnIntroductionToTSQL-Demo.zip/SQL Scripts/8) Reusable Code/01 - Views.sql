/*------------------------------------------------------------------------------------
	VIEWs
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Using a View
-----------------------------------------------

/*
	Imagine we have some newbie developers or people with little SQL knowledge...

	We have the following tables
*/

select *
from JupyterDatabase.hr.employee;

select *
from JupyterDatabase.hr.jobTitle;

select *
from JupyterDatabase.hr.department;


/*
	We know what we are doing, therefore we can obtain information easily
*/

select e.employeeID, e.title, e.firstName, e.lastName,
		concat_ws(' ', e.title, e.firstName, e.lastName) as fullname,
		t.jobTitle, d.department
from JupyterDatabase.hr.employee as e
join JupyterDatabase.hr.jobTitle as t
on e.jobTitleID = t.jobTitleID
join JupyterDatabase.hr.department as d
on t.departmentID = d.departmentID;


/*
	Our newbie developers cannot produce this commonly used information

	Therefore we can use a view
*/

drop view if exists hr.vwEmployeeInfoTest
go

create view hr.vwEmployeeInfoTest
as
	select e.employeeID, e.title, e.firstName, e.lastName,
			concat_ws(' ', e.title, e.firstName, e.lastName) as fullname,
			t.jobTitle, d.department
	from JupyterDatabase.hr.employee as e
	join JupyterDatabase.hr.jobTitle as t
	on e.jobTitleID = t.jobTitleID
	join JupyterDatabase.hr.department as d
	on t.departmentID = d.departmentID;
go

select *
from hr.vwEmployeeInfoTest;
go


-----------------------------------------------
-- Altering a View
-----------------------------------------------

/*
	If we wished to amend the view definition, we can do so using ALTER
*/

alter view hr.vwEmployeeInfoTest
as
	select e.employeeID, e.title, e.firstName, e.lastName,
			concat_ws(' ', e.lastName + ',', e.firstName) as fullname,
			t.jobTitle, d.department
	from JupyterDatabase.hr.employee as e
	join JupyterDatabase.hr.jobTitle as t
	on e.jobTitleID = t.jobTitleID
	join JupyterDatabase.hr.department as d
	on t.departmentID = d.departmentID;
go

