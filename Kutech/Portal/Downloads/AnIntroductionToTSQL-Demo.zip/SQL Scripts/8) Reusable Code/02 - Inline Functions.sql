/*------------------------------------------------------------------------------------
	Inline Functions
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Examples
-----------------------------------------------

/*
	These are functions that we have seen already throughout our travels
*/

select firstName, lastName, (firstName + ' ' + lastName) as fullName
from JupyterDatabase.hr.employee;


select year(orderDate) orderYear, sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
group by YEAR(orderDate);


-----------------------------------------------
-- Performance
-----------------------------------------------

/*
	Beware of 'hiding columns from SQL Server'
*/

select year(orderDate) orderYear, sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
where year(orderDate) = 2019
group by YEAR(orderDate);


/*
	This should be written as follows
*/

select year(orderDate) orderYear, sum(totalDue) as totalSales
from JupyterDatabase.sales.salesOrderHeader
where orderDate between '2019-01-01' and '2019-12-31 23:59:59.999'
group by YEAR(orderDate);
