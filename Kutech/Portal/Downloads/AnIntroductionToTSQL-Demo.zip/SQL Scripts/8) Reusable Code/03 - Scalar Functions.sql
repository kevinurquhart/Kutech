/*------------------------------------------------------------------------------------
	Scalar Functions
------------------------------------------------------------------------------------*/

-----------------------------------------------
-- Basic Function
-----------------------------------------------

/*
	This is a very basic example of a Scalar Function

	It returns just the current date and time
*/

drop function if exists dbo.fnGetDate
go

create function dbo.fnGetDate()
returns datetime
as
begin
	return(select current_timestamp)
end
go


/*
	We access it in the SELECT or WHERE clause as follows
*/

select JupyterDatabase.dbo.fnGetDate();


select top 10 employeeID, firstName, lastName, dbo.fnGetDate() as currentTime
from JupyterDatabase.hr.employee
order by employeeID;


-----------------------------------------------
-- Function with Parameter
-----------------------------------------------

/*
	We can also create functions which we can pass parameters to
*/

drop function if exists dbo.fnGetDateAdjust
go

create function dbo.fnGetDateAdjust
(
    @numDays int
)
returns datetime
as
begin
	return
    (
        select dateadd(dd, @numDays, current_timestamp)
    )
end
go


/*
	We can therefore now enter a value into our brackets as our parameter
*/

select dbo.fnGetDateAdjust(1) as nowPlus1Day,
        dbo.fnGetDateAdjust(2) as nowPlus2Days;


/*
	We can also see this used in terms of full name
*/

drop function if exists dbo.fnFullName
go

create function dbo.fnFullName
(
    @firstName varchar(25),
	@lastName varchar(35)
)
returns varchar(61)
as
begin
	return
    (
        select CONCAT_WS(' ', @firstName, @lastName)
    )
end
go


/*
	This is called in the same way
*/

select JupyterDatabase.dbo.fnFullName('John', 'Smith');


/*
	We can also pass columns as parameters
*/

select top 10 employeeID, firstName, lastName,
        JupyterDatabase.dbo.fnFullName(firstname, lastName) as fullName
from JupyterDatabase.hr.employee
order by employeeID;


-----------------------------------------------
-- Performance
-----------------------------------------------

/*
	Beware of 'hiding columns from SQL Server'
*/

select employeeID, firstName, lastName,
        dbo.fnFullName(firstname, lastName) as fullName
from hr.employee
where dbo.fnFullName(firstname, lastName) = 'Kevin Urquhart';


/*
	This is better written as follows
*/

select employeeID, firstName, lastName,
        JupyterDatabase.dbo.fnFullName(firstname, lastName) as fullName
from JupyterDatabase.hr.employee
where firstname = 'Kevin'
and lastName = 'Urquhart';


-----------------------------------------------
-- Table Based Scalar Functions
-----------------------------------------------

/*
	Our functions can also run queries that access tables

	This means we can pass in IDs and have our functions interpret them
*/

drop function if exists dbo.fnFullNameTable
go

create function dbo.fnFullNameTable
(
    @employeeID int
)
returns varchar(61)
as
begin
	return
    (
        select CONCAT_WS(' ', firstName, lastName)
		from JupyterDatabase.hr.employee
		where employeeID = @employeeID
    )
end
go


/*
	These are used in the same way
*/

select top 10 employeeID, firstName, lastName,
        dbo.fnFullNameTable(employeeID) as fullName
from hr.employee
order by employeeID;


-----------------------------------------------
-- Performance
-----------------------------------------------

/*
	Here we have two Options for functions that do the same task
*/

-- Option 1

select employeeID, firstName, lastName,
        JupyterDatabase.dbo.fnFullName(firstname, lastName) as fullName
from JupyterDatabase.hr.employee;

-- Option 2

select employeeID, firstName, lastName,
        JupyterDatabase.dbo.fnFullNameTable(employeeID) as fullName
from JupyterDatabase.hr.employee;


/*
	Option One

		This will read the hr.employee table once in entirety.

		For each record it will read the firstName and lastName,
		the function will concatenate them, and the record will be returned.

		Therefore, for a 1 million record table, SQL Server
		will read 1 million records in order to obtain our answer.

	Option Two

		As we have no indexes on our employee table, for SQL Server to satisfy
		WHERE employeeID = @employeeID it will need to read every record in our table.

		This means that for every row SQL Server needs to read the row itself and
		then 1 million rows to look for the correct employeeID in order to return a full name.

		The results of this maths are astronomical (1 million lots of 1 million and 1 records)
		and therefore, even without listing a very large number here, it's immediately apparent
		that Table Based Scalar Functions can have a very negative impact on performance.
		These, therefore, need to be used wisely.
*/

