/*------------------------------------------------------------------------------------
	Table Valued Functions
------------------------------------------------------------------------------------*/

/*
	These return tables instead of just individual values
*/

-----------------------------------------------
-- Basic TVF
-----------------------------------------------

/*
	We will simply use the View we created earlier
*/

drop view if exists hr.vwEmployeeInfoTest
go

create view hr.vwEmployeeInfoTest
as
	select e.employeeID, e.title, e.firstName, e.lastName,
			concat_ws(' ', e.title, e.firstName, e.lastName) as fullname,
			t.jobTitle, d.department
	from JupyterDatabase.hr.employee as e
	join JupyterDatabase.hr.jobTitle as t
	on e.jobTitleID = t.jobTitleID
	join JupyterDatabase.hr.department as d
	on t.departmentID = d.departmentID;
go


/*
	But we will recreate this as a TVF
*/

drop function if exists hr.fnEmployeeInfoTest
go

create function hr.fnEmployeeInfoTest()
returns @myTable table
(
    employeeID int,
    title varchar(10),
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(61),
    jobTitle varchar(50),
    department varchar(50)
)
as
begin
    insert into @myTable
    (
        employeeID, title, firstName, lastName,
		fullName, jobTitle, department
    )
	select e.employeeID, e.title, e.firstName, e.lastName,
			concat_ws(' ', e.title, e.firstName, e.lastName) as fullname,
			t.jobTitle, d.department
	from JupyterDatabase.hr.employee as e
	join JupyterDatabase.hr.jobTitle as t
	on e.jobTitleID = t.jobTitleID
	join JupyterDatabase.hr.department as d
	on t.departmentID = d.departmentID;

	return
end
go


/*
	This can be used like a table, with the exception that being a function means it has brackets
*/

select *
from JupyterDatabase.hr.fnEmployeeInfoTest();


/*
	To see why this is useful we'll consider this revised view
*/

drop view if exists hr.vwEmployeeInfoYearTest
go

create view hr.vwEmployeeInfoYearTest
as
	select e.employeeID, e.title, e.firstName, e.lastName,
			concat_ws(' ', e.title, e.firstName, e.lastName) as fullname,
			t.jobTitle, d.department,
            year(e.dob) as birthYear  -- Add the year of birth to the output list
	from JupyterDatabase.hr.employee as e
	join JupyterDatabase.hr.jobTitle as t
	on e.jobTitleID = t.jobTitleID
	join JupyterDatabase.hr.department as d
	on t.departmentID = d.departmentID;
go

select *
from JupyterDatabase.hr.vwEmployeeInfoYear
where birthYear < 1960;


/*
	Using the above, we need to generate the entire results set before we can filter

	This is less than performant

	Now consider a function
*/

drop function if exists hr.fnEmployeeInfoYearTest
go

create function hr.fnEmployeeInfoYearTest(@year date)  -- Add parameter to the function.  We will pass in a date.
returns @myTable table
(
    employeeID int,
    title varchar(10),
    firstName varchar(25),
    lastName varchar(35),
    fullName varchar(61),
    jobTitle varchar(50),
    department varchar(50)
)
as
begin
    insert into @myTable
    (
        employeeID, title, firstName, lastName,
		fullName, jobTitle, department
    )
	select e.employeeID, e.title, e.firstName, e.lastName,
			concat_ws(' ', e.title, e.firstName, e.lastName) as fullname,
			t.jobTitle, d.department
	from JupyterDatabase.hr.employee as e
	join JupyterDatabase.hr.jobTitle as t
	on e.jobTitleID = t.jobTitleID
	join JupyterDatabase.hr.department as d
	on t.departmentID = d.departmentID
    where e.dob < @year;     -- Add a filter which can act on the hr.employee table directly and with good performance

	return
end
go

select *
from JupyterDatabase.hr.fnEmployeeInfoYear('1960-01-01');


/*
	In the above, we can filter straight away without pre-generating the results

	This is much more efficient
*/


-----------------------------------------------
-- APPLY and JOINs
-----------------------------------------------

/*
	If you are tyring to JOIN to a TVF and passing in a parameter, you need to use APPLY

	Let's consider this function
*/

drop function if exists sales.fnSalesPerPersonTest
go

create function sales.fnSalesPerPersonTest(@employeeID int)
returns @myTable table
(
	employeeID int,
	salesTotal decimal(10, 2)
)
as
begin
	insert into @myTable(employeeID, salesTotal)
	select salesPersonID, sum(totalDue)
	from sales.salesOrderHeader
	where salesPersonID = @employeeID
	group by salesPersonID;

	return
end
go


/*
	The following will fail
*/

select e.employeeID, e.firstName, e.lastName, s.salesTotal
from JupyterDatabase.hr.employee as e
join JupyterDatabase.sales.fnSalesPerPerson(e.employeeID) as s
on e.employeeID = s.employeeID
where e.employeeID in (41, 49, 52);


/*
	We cannot reference a column from another table within a JOIN

	We can only reference columns in the ON clause and not before

	However, with APPLY we can achieve this
		ON isn't relevant and is done within the JOIN itself
*/

select e.employeeID, e.firstName, e.lastName, s.salesTotal
from JupyterDatabase.hr.employee as e
cross apply JupyterDatabase.sales.fnSalesPerPerson(e.employeeID) as s
where e.employeeID in (41, 49, 52);

