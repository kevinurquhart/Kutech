/*------------------------------------------------------------------------------------
	Stored Procedures
------------------------------------------------------------------------------------*/

/*
	These are the pinnacle of centralised and reusable code

	They can return many different types of data and multiple result sets

	SQL Server was designed to run Stored Procedures

	We are allowed to create temporary stored procedures, which works well for demo scripts
*/

-----------------------------------------------
-- Single Value Stored Procedure
-----------------------------------------------

/*
	This has no parameters and returns just a single value
*/

drop procedure if exists #basicTimeProc
go

create procedure #basicTimeProc
as
    select current_timestamp as currentDateTime
go


-----------------------------------------------
-- Executing a Procedure
-----------------------------------------------

/*
	We use EXEC
*/

exec #basicTimeProc
go


-----------------------------------------------
-- Returning a Table
-----------------------------------------------

/*
	This is the next logical step, to return a table
*/

drop procedure if exists #basicEmployeeInfo
go

create procedure #basicEmployeeInfo
as
    select e.employeeID, e.title, e.firstName, e.lastName,
			concat_ws(' ', e.title, e.firstName, e.lastName) as fullname,
			t.jobTitle, d.department
	from JupyterDatabase.hr.employee as e
	join JupyterDatabase.hr.jobTitle as t
	on e.jobTitleID = t.jobTitleID
	join JupyterDatabase.hr.department as d
	on t.departmentID = d.departmentID
go

exec #basicEmployeeInfo
go


-----------------------------------------------
-- Passing a Parameter
-----------------------------------------------

/*
	We are allowed to pass parameters to Stored Procedures
*/

drop procedure if exists #parameterTimeProc
go

create procedure #parameterTimeProc
(
    @numDays int
)
as
    select dateadd(dd, @numDays, current_timestamp) as RequiredDateTime
go

exec #parameterTimeProc 1
go


/*
	We can pass multiple parameters

	We can also explicitly define which parameter value we assign to which parameter
*/

drop procedure if exists #parameterTimeProc
go

create procedure #variableTimeProc
(
    @firstName varchar(25),
    @lastName varchar(35)
)
as
    select employeeID, firstName, lastName,
            concat_ws(' ', firstname, lastName) as fullName,
            salary, managerID
    from JupyterDatabase.hr.employee
    where firstname = @firstName
    and lastName = @lastName;
go

exec #variableTimeProc @firstName = 'Kevin', @lastName = 'Urquhart'
go


/*
	We can also have optional parameters

	These effectively supply default values if not explicitly used

	Firstly let's look at some data in our table
*/

select salesPersonID, sum(totalDue) SalesTotal, count(*) NumSales
from JupyterDatabase.sales.salesOrderHeader
where salesPersonID in (46, 47)
group by salesPersonID;


/*
	We can see SalesPersonID 46 has many more sales than 47

	They can easily be separated by sales total or number of sales

	Now, let's create a very specific and clearly rigged Stored Procedure that has three parameters;
		employeeID, salesTotal, and salesCount.
	We will make create it so that the latter two parameters have default values of 15 million and 80,000 respectively.

	We shall then execute the Stored Procedure a total of 3 times with a variety of parameter
	options to become comfortable with the syntax around default parameters:

		Only employeeID
		EmployeeID and SalesTotal
		All three parameters

	First we shall create our Stored Procedure, including our three parameters,
	two of which will have default values assigned:
*/

drop procedure if exists #parameterSalesDefaults
go

create procedure #parameterSalesDefaults
(
    @employeeID int,
    @salesTotal decimal(15, 2) = 15000000,  -- Parameter created with a default value
	@salesCount int = 80000                 -- Parameter created with a default value
)
as
    select salesPersonID, sum(totalDue) as salesTotal,
			count(*) as salesCount
	from JupyterDatabase.sales.salesOrderHeader
	where salesPersonID = @employeeID       -- @employeeID used in the WHERE clause
	group by salesPersonID
	having sum(totalDue) > @salesTotal      -- @salesTotal used in the HAVING clause
	and count(*) > @salesCount;             -- @salesCount used in the HAVING clause
go

/*
	We can now call this with just employeeID

	We expect the HAVING clause to allow employeeID 46 but not 47
*/

exec #parameterSalesDefaults @employeeID = 46;
exec #parameterSalesDefaults @employeeID = 47;
go


/*
	We can override our salesTotal with very high numbers ensuring no-one is returned
*/

exec #parameterSalesDefaults @employeeID = 46, @salesTotal = 20000000;
exec #parameterSalesDefaults @employeeID = 47, @salesTotal = 20000000;
go

/*
	Lastly, we can pass in very low values for each parameter to allow both employeeIDs to return
*/

exec #parameterSalesDefaults @employeeID = 46, @salesTotal = 10000, @salesCount = 100;
exec #parameterSalesDefaults @employeeID = 47, @salesTotal = 10000, @salesCount = 100;
go


-----------------------------------------------
-- Returning Multiple Datasets
-----------------------------------------------

/*
	Maybe one result set is not enough and we wish to return several datasets at once.
	This can easily be done by a Stored Procedure.

	We wish to create a single Stored Procedure to return the following:

		The current date and time of execution
		The Employee Info about our passed in EmployeeID
		The Employee's Sales Summary (total Sales by Year)
	
	This would be impossible with a Function or a View as each only allows one result
	set to be returned and in the form of a single table.
*/

/*
	Piece 1 - The current date and time
*/

select current_timestamp as executionTime;
go

/*
	Piece 2 - Employee Info
*/

declare @employeeID int;

select @employeeID = 46;

select e.employeeID, e.title, e.firstName, e.lastName,
        concat_ws(' ', e.title, e.firstName, e.lastName) as fullname,
        t.jobTitle, d.department
from JupyterDatabase.hr.employee as e
join JupyterDatabase.hr.jobTitle as t
on e.jobTitleID = t.jobTitleID
join JupyterDatabase.hr.department as d
on t.departmentID = d.departmentID
where e.employeeID = @employeeID;
go

/*
	Piece 3 - The employee's sales figures
*/

declare @employeeID int;

select @employeeID = 46;

select salesPersonID, sum(totalDue) as salesTotal
from JupyterDatabase.sales.salesOrderHeader
where salesPersonID = @employeeID
group by salesPersonID;
go


/*
	Place them into one single stored procedure
*/

drop procedure if exists #multiTable
go

create procedure #multiTable
(
    @employeeID int
)
as
    select current_timestamp as executionTime;

    select e.employeeID, e.title, e.firstName, e.lastName,
            concat_ws(' ', e.title, e.firstName, e.lastName) as fullname,
            t.jobTitle, d.department
    from JupyterDatabase.hr.employee as e
    join JupyterDatabase.hr.jobTitle as t
    on e.jobTitleID = t.jobTitleID
    join JupyterDatabase.hr.department as d
    on t.departmentID = d.departmentID
    where e.employeeID = @employeeID;

    select salesPersonID, sum(totalDue) as salesTotal
    from JupyterDatabase.sales.salesOrderHeader
    where salesPersonID = @employeeID
    group by salesPersonID;
go

exec #multiTable 46
go


-----------------------------------------------
-- Capturing Outputs
-----------------------------------------------

/*
	If we're returning data to an application then this isn't an issue

	If we wish to return to ourselves for further use or analysis, we need to capture the outputs
*/

-----------------------------------------------
-- Capturing Values
-----------------------------------------------

/*
	In order to achieve this we need to do the following:

		CREATE a Stored Procedure
			Include an OUTPUT parameter
		DECLARE a variable in our T-SQL batch
		EXECUTE the Stored Procedure
			Tell it to assign the output parameter to our variable
	
	Then we can reuse the newly assigned variable for the remainder of our batch.
*/

drop procedure if exists #salesTotal
go

create procedure #salesTotal
(
	@employeeID int,
	@salesTotal decimal(15, 2) output			-- We simply need add the 'output' keyword to our parameter
)
as
	select @salesTotal = sum(totalDue)			-- Assign our value to the variable
	from JupyterDatabase.sales.salesOrderHeader
	where salesPersonID = @employeeID;
go

declare @salesAmount decimal(15, 2);			-- DECLARE our variable

exec #salesTotal 46, @salesAmount output;		-- Tell SQL Server to place the OUTPUT parameter into our variable

select @salesAmount as returnedOutput;			-- Use our variable as we please, in this case just display it
go


-----------------------------------------------
-- Capturing a Table
-----------------------------------------------

/*
	Capturing the data from a Stored Procedure into a Table is actually a little simpler than a single value.

	Note we can only capture ONE table, therefore this is all our procs can return when capture is needed.

	In this circumstance we need to create a temporary table (or real table, but most likely a temporary one)
	which mimics the output results and then we simply tell our Stored Procedure to Insert its output into that table.

	We have the following procedure
*/

drop procedure if exists #allSalesData
go

create procedure #allSalesData
as
    select salesPersonID, sum(totalDue) as salesTotal,
			count(*) as salesCount
	from JupyterDatabase.sales.salesOrderHeader
	group by salesPersonID;
go

exec #allSalesData;
go


/*
	We can therefore create the following table to store the output
*/

drop table if exists #allSalesDataTable
go

create table #allSalesDataTable
(
    salesPersonID int,
    salesTotal decimal(15, 2),
    salesCount int
)
go


/*
	We can now execute our proc and tell SQL to INSERT the results into our table
*/

insert into #allSalesDataTable
(
    salesPersonID, salesTotal, salesCount
)
exec #allSalesData;
go

-- Now we can use this data:
select *
from #allSalesDataTable
order by salesTotal desc;
go
